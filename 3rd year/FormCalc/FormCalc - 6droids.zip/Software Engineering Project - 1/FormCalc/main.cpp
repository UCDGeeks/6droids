/**
*
*Team ~6Droids~
*
*/

#include <QApplication>

//#include "formcalc_advance.h"
//#include "formcalc_scientific.h"
//#include "mainwindow.h"
#include "dependencies.h"
#include <QSplashScreen>
#include <QTimer>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    FormCalc_Scientific w;

    QSplashScreen *splash = new QSplashScreen;
    splash->setPixmap(QPixmap(":icon/SplashImage.png"));
    splash->show();

    //dependencies d;
     //d.openScientific();
    //MainWindow w;


    QTimer::singleShot(2500,splash,SLOT(close()));
    QTimer::singleShot(2500,&w,SLOT(show()));

    //d.openMainWindow();

    //d.openGraph();

    //w.show();

    return a.exec();
}

/**
*
*Team ~6Droids~
*
*/

#include "formcalc_advance.h"
#include "ui_formcalc_advance.h"

Formcalc_advance::Formcalc_advance(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Formcalc_advance)
{
    ui->setupUi(this);
    //connect(ui->basic_btn, SIGNAL(clicked()), this, SLOT(Formcalc_advance::on_basic_btn_clicked()));
    //connect(ui->scientific_btn, SIGNAL(clicked()), this, SLOT(Formcalc_advance::on_scientific_btn_clicked()));
}

Formcalc_advance::~Formcalc_advance()
{
    delete ui;
}


void Formcalc_advance::on_graph_btn_clicked(){

    /*  advance = new Formcalc_advance();
        advance->show();  */
    dependencies d;
    d.openGraph();
    //this->close();

}



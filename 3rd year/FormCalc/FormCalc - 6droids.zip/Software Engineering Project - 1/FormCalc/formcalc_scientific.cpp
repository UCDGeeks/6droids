/**
*
*Team ~6Droids~
*
*/

#include "formcalc_scientific.h"
#include "ui_formcalc_scientific.h"
#include <qstring.h>
#include <math.h>
#include <QKeyEvent>
#include <QMessageBox>
#include <QInputDialog>

bool oparatorclick = false , numberClick = false;

bool totalSelected = false, valueSelected = false, commandSelected = false;


FormCalc_Scientific::FormCalc_Scientific(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::FormCalc_Scientific)
{
    ui->setupUi(this);
    ui->total_txtline->installEventFilter(this);
    ui->values_txtline->installEventFilter(this);
    ui->command_txtline->installEventFilter(this);
}


bool FormCalc_Scientific::eventFilter(QObject *obj, QEvent *event)
{
    if (event->type() == QEvent::FocusOut)
    {
        if (obj == ui->total_txtline){
            totalSelected = true;
            valueSelected = false;
        }

        if (obj == ui->values_txtline){
            totalSelected = false;
            valueSelected = true;
        }

        if (obj == ui->command_txtline){
            totalSelected = false;
            valueSelected = false;
        }



        //if (obj == ui->lineEdit_3)
          // QMessageBox::information(this, "", "line3");

    }

    return false;
}


FormCalc_Scientific::~FormCalc_Scientific()
{
    delete ui;
}

void FormCalc_Scientific::on_graph_btn_clicked()
{
    dependencies d;
    d.openGraph();
    //this->close();
}



/**
 * @brief FormCalc_Scientific::appenedin
 *  -appending is the function which all the numpad buttons calls when they were clicked.
 *
 * @param totalline
 *  -totalline is which types on the total_txtline.
 */
void FormCalc_Scientific::appenedin(QString totalline)
{

    //numberClick = true;
    oparatorclick = false;

    if(totalSelected){
        QString input = ui->total_txtline->text();
        ui->total_txtline->setText(input+totalline);

    }
    else if(valueSelected){
        QString input = ui->values_txtline->text();
        ui->values_txtline->setText(input+totalline);

    }
    else if(commandSelected){
        totalSelected = false;
        valueSelected = false;
    }

    /*if(oparatorclick){
         QString input = ui->total_txtline->text();
         ui->total_txtline->setText(totalline);
         oparatorclick = false;
     }
     else{
         QString input = ui->total_txtline->text();
         ui->total_txtline->setText(input+totalline);
     }*/

}

/**
 * @brief FormCalc_Scientific::notempty_appenedin
 *
 * @param op
 */
void FormCalc_Scientific::notempty_appenedin(QString op)
{
    //numberClick = false;


    if(totalSelected){
        if(!oparatorclick){
            oparatorclick = true;
           QString input = ui->total_txtline->text();
           ui->total_txtline->setText(input+op);
        }
        else{

        }
    }
    else if(valueSelected){
        if(!oparatorclick){
            oparatorclick = true;
           QString input = ui->values_txtline->text();
           ui->values_txtline->setText(input+op);
        }
        else{

        }
    }



   /* if(numberClick){
        numberClick = false;
        if(ui->total_txtline->text().isEmpty()){
            ui->total_txtline->setText("0"+op);
            //ui->formular_txtline->setText("0"+op);
        }*/

        /*else if(ui->formular_txtline->text().isEmpty()){

            //QString previnput = ui->formular_txtline->text();
            QString input = ui->total_txtline->text();
            ui->formular_txtline->setText(input+op);

        }*/

        //else{
            //QString previnput = ui->formular_txtline->text();
            //QString input = ui->total_txtline->text();
            //ui->formular_txtline->setText(previnput+input+op);
       // }
//    }
//    else {

      //  QString previnput = ui->formular_txtline->text();
      //  previnput.remove(previnput.size()-1, previnput.size());

      //  ui->formular_txtline->setText(previnput+op);

    //}

       // QString input = ui->total_txtline->text();
       // QString inputformular = ui->formular_txtline->text();
       // ui->formular_txtline->setText(input+op);

}



//Print numpad numbers to textline
void FormCalc_Scientific::on_zero_btn_clicked()
{
    if(ui->total_txtline->text()==("0")){

    }
    else{
    appenedin("0");
    }
}

void FormCalc_Scientific::on_one_btn_clicked()
{
    appenedin("1");
}

void FormCalc_Scientific::on_two_btn_clicked()
{
    appenedin("2");
}

void FormCalc_Scientific::on_three_btn_clicked()
{
    appenedin("3");
}

void FormCalc_Scientific::on_four_btn_clicked()
{
    appenedin("4");
}

void FormCalc_Scientific::on_five_btn_clicked()
{
    appenedin("5");
}

void FormCalc_Scientific::on_six_btn_clicked()
{
    appenedin("6");
}

void FormCalc_Scientific::on_seven_btn_clicked()
{
    appenedin("7");
}

void FormCalc_Scientific::on_eight_btn_clicked()
{
    appenedin("8");
}

void FormCalc_Scientific::on_nine_btn_clicked()
{
    appenedin("9");
}

void FormCalc_Scientific::on_dot_btn_clicked()
{
    valueSelected = false;
    if(ui->total_txtline->text().isEmpty()){

    }
    else if(ui->total_txtline->text().contains(".")){

    }
    else{
    appenedin(".");
    }
}

void FormCalc_Scientific::on_plus_btn_clicked()
{
    valueSelected = false;
    //oparatorclick = true;
    notempty_appenedin("+");
    //appenedin("+");
}

void FormCalc_Scientific::on_min_btn_clicked()
{
    valueSelected = false;
    //oparatorclick = true;
    notempty_appenedin("-");
}

void FormCalc_Scientific::on_multiply_btn_clicked()
{
    valueSelected = false;
    //oparatorclick = true;
    notempty_appenedin("*");
}

void FormCalc_Scientific::on_divide_btn_clicked()
{
    valueSelected = false;
    //oparatorclick = true;
    notempty_appenedin("/");
}
//-END-Print numpad numbers to textline

void FormCalc_Scientific::on_c_btn_clicked()
{
    //ui->formular_txtline->setText("");
    ui->total_txtline->clear();
    ui->values_txtline->clear();
    ui->recent_combo->clear();
    ui->history_combo->clear();
}

void FormCalc_Scientific::on_ce_btn_clicked()
{
    //ui->total_txtline->setText("");
    ui->total_txtline->clear();
}

void FormCalc_Scientific::on_plusormin_btn_clicked()
{
    valueSelected = false;
    QString input = ui->total_txtline->text();
    if(ui->total_txtline->text().contains("-")){
        input.remove(0,1);
        ui->total_txtline->setText(input);
    }
    else{
        ui->total_txtline->setText("-"+input);
    }
}

void FormCalc_Scientific::on_del_btn_clicked()
{
    if(totalSelected){
        QString input = ui->total_txtline->text();
        input = input.remove( (input.size()-1) , (input.size()) );
        ui->total_txtline->setText(input);
    }
    else if(valueSelected){
        QString input = ui->values_txtline->text();
        input = input.remove( (input.size()-1) , (input.size()) );
        ui->values_txtline->setText(input);
    }
}

void FormCalc_Scientific::on_openbrace_btn_clicked()
{
    valueSelected = false;
    appenedin("(");
}

void FormCalc_Scientific::on_closebrace_btn_clicked()
{
    valueSelected = false;
    appenedin(")");
}


void FormCalc_Scientific::on_cosec_btn_clicked()
{
    valueSelected = false;
    appenedin("cosec(");
}

void FormCalc_Scientific::on_sin_btn_clicked()
{
    valueSelected = false;
    appenedin("sin(");
}

void FormCalc_Scientific::on_sec_btn_clicked()
{
    valueSelected = false;
    appenedin("sec(");
}

void FormCalc_Scientific::on_cos_btn_clicked()
{
    valueSelected = false;
    appenedin("cos(");
}

void FormCalc_Scientific::on_cot_btn_clicked()
{
    valueSelected = false;
    appenedin("cot(");
}

void FormCalc_Scientific::on_tan_btn_clicked()
{
    valueSelected = false;
    appenedin("tan(");
}

void FormCalc_Scientific::on_pi_btn_clicked()
{
    valueSelected = false;
    //appenedin("3.1415926535897932384626433832795");
    appenedin("pi");
}

void FormCalc_Scientific::on_square_btn_clicked()
{
    valueSelected = false;
    if(ui->total_txtline->text().isEmpty()){

      }
    else {
        appenedin("^2");
    }

}

void FormCalc_Scientific::on_x_btn_clicked()
{
    appenedin("x");
    /*if(totalSelected){
        QString input = ui->total_txtline->text();
        ui->total_txtline->setText(input+"x");

    }
    else if(valueSelected){
        QString input = ui->values_txtline->text();
        ui->values_txtline->setText(input+"x");

    }*/

}

void FormCalc_Scientific::on_y_btn_clicked()
{

    appenedin("y");

    /*if(totalSelected){
        QString input = ui->total_txtline->text();
        ui->total_txtline->setText(input+"y");

    }
    else if(valueSelected){
        QString input = ui->values_txtline->text();
        ui->values_txtline->setText(input+"y");

    }*/
}

void FormCalc_Scientific::on_z_btn_clicked()
{
    appenedin("z");

    /*if(totalSelected){
        QString input = ui->total_txtline->text();
        ui->total_txtline->setText(input+"z");

    }
    else if(valueSelected){
        QString input = ui->values_txtline->text();
        ui->values_txtline->setText(input+"z");

    }*/
}

void FormCalc_Scientific::on_xpowery_btn_clicked()
{
    valueSelected = false;
    if(ui->total_txtline->text().isEmpty()){

      }
    else {
        appenedin("^");
    }


}

void FormCalc_Scientific::on_reload_btn_clicked()
{
    /*
    QString s = QFileDialog::getOpenFileName(this, tr("Open Image"), "/home/jana", tr("Image Files (*.png *.jpg *.bmp)"));
    appenedin(s);  */

    QString fileName = QFileDialog::getOpenFileName(this, tr("Open Source"), "./", tr("Text Files (*.txt)"));

    std::string strFileName = fileName.toLocal8Bit().constData();

    std::string line;
    std::ifstream myfile (&strFileName[0]);
    if (myfile.is_open())
    {
    while ( getline (myfile,line) )
    {
    QString lineQString(&line[0]);
    ui->history_combo->addItem(lineQString);
    //appenedin(lineQString);
    }
    myfile.close();
    }
}

void FormCalc_Scientific::on_log_btn_clicked()
{
    valueSelected = false;
    appenedin("lg(");
}

void FormCalc_Scientific::on_cube_btn_clicked()
{
    valueSelected = false;
    if(ui->total_txtline->text().isEmpty()){

      }
    else {
        appenedin("^3");
    }
}

void FormCalc_Scientific::on_npr_btn_clicked()
{
    valueSelected = false;
    if(ui->total_txtline->text().isEmpty()){

      }
    else {
        appenedin("P");
    }
}

void FormCalc_Scientific::on_ncr_btn_clicked()
{
    valueSelected = false;
    if(ui->total_txtline->text().isEmpty()){

      }
    else {
        appenedin("C");
    }
}

void FormCalc_Scientific::on_int_btn_clicked()
{
    QString s =  ui->total_txtline->text();

    QString printval = QString::number(round( QVariant( s ).toDouble()  ));

    ui->total_txtline->setText( printval );

    /*QString input = ui->total_txtline->text();
    QString fract = ".";
    int indexval = input.indexOf(fract);
    QString righttext = input.right(indexval-1);
    ui->values_txtline->setText(righttext);*/
}


void FormCalc_Scientific::on_ln_btn_clicked()
{
    valueSelected = false;
    appenedin("ln(");
}



void FormCalc_Scientific::on_cuberoot_btn_clicked()
{
    valueSelected = false;
    if(ui->total_txtline->text().isEmpty()){

      }
    else {
        appenedin("3√");
    }
}

void FormCalc_Scientific::on_nthrooth_btn_clicked()
{
    valueSelected = false;
    if(ui->total_txtline->text().isEmpty()){

      }
    else {
        appenedin("√");
    }
}

void FormCalc_Scientific::on_inverselog_btn_clicked()
{
    valueSelected = false;
    appenedin("10^");
}

void FormCalc_Scientific::on_total_txtline_returnPressed()
{
    //QComboBox::InsertAtTop;
    QString input = ui->total_txtline->text();
    input.simplified();
    input.replace(" ", "");

    if(input.contains("f(x)")){
       // ui->history_combo->addItem(input);
        ui->recent_combo->addItem(input);
    }
    else if(input.contains("g(x)")){
       // ui->history_combo->addItem(input);
        ui->recent_combo->addItem(input);
    }
    else if(input.contains("h(x)")){
       // ui->history_combo->addItem(input);
        ui->recent_combo->addItem(input);
    }else{
        FormulaElement* formula = FormulaElement::parseFormula( input.toStdString() );
        ui->total_txtline->setText( QString::number( formula->evaluate() ) );
    }
    //ui->recent_combo->addItem(input);

}


void FormCalc_Scientific::on_recent_combo_currentIndexChanged(const QString &arg1)
{
    ui->total_txtline->setText(ui->recent_combo->currentText());
}

void FormCalc_Scientific::on_history_combo_currentIndexChanged(const QString &arg1)
{
    ui->total_txtline->setText(ui->history_combo->currentText());
}

void FormCalc_Scientific::on_equal_btn_clicked()
{
    appenedin("=");
}

void FormCalc_Scientific::on_evl_btn_clicked()
{
    if(ui->total_txtline->text().isEmpty()){

        if(ui->values_txtline->text().isEmpty()){
            QMessageBox::warning(
                    this,
                    tr("Empty variables!"),
                    tr("Please enter valid varable values!") );
            ui->values_txtline->setFocus();
        }else{

            QMessageBox::warning(
                    this,
                    tr("Empty Formular!"),
                    tr("Please enter a valid formular!") );
            ui->total_txtline->setFocus();
        }
    }
    else
    {

        if(ui->values_txtline->text().isEmpty()){
            QMessageBox::warning(
                    this,
                    tr("Empty variables!"),
                    tr("Please enter valid varable values!") );
            ui->values_txtline->setFocus();
        }else{
            QString input = ui->total_txtline->text();
            QString inputVal = ui->values_txtline->text();
            input = input.right(input.indexOf("="));
            input.simplified();
            input.replace(" ", "");

            FormulaElement* formula = FormulaElement::parseFormula( input.toStdString() );

            std::vector<variableValue*> val;
            variableValue v;
            v.variable = "X";
            v.value = inputVal.toDouble();
            val.push_back(&v);
            formula->setVariableValues(&val);

            // formula->evaluate()
            QString evaluateVal = QString::number( formula->evaluate() );
            ui->total_txtline->setText( evaluateVal );
            ui->recent_combo->addItem(input);
        }
    }
}

void FormCalc_Scientific::on_save_btn_clicked()
{
    QString formulaToBeSaved = ui->total_txtline->text();
    //formulaToBeSaved.append("\n");

    QString saveFilePath = QFileDialog::getSaveFileName(this, tr("Save File"),"./untitled.txt", tr("Text file (*.txt)"));
    std::string strSaveFilePath = saveFilePath.toLocal8Bit().constData();

    QFile file(&strSaveFilePath[0]);
    if (file.open(QIODevice::ReadWrite)) {
    QTextStream stream(&file);
    QString fileread = stream.readAll();
    //stream << fileread << "\n";
    stream << formulaToBeSaved << "\n";
    }

    file.close();
}

void FormCalc_Scientific::on_command_txtline_returnPressed()
{
    QString input = ui->command_txtline->text();
    input.toLower();
    input.simplified();
    input.replace(" ", "");
    QString inputval = input;

    if(inputval.contains("savegraph")){
        on_save_btn_clicked();
    }
    else if(inputval.contains("reload")){
        on_reload_btn_clicked();
    }
    else if(input.contains("clear")){
        on_ce_btn_clicked();
    }
    else if(input.contains("clearall")){
        on_c_btn_clicked();
    }
}

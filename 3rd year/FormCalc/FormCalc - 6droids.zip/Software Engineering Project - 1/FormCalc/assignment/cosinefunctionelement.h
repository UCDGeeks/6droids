    #ifndef COSINEFUNCTIONELEMENT_H
#define COSINEFUNCTIONELEMENT_H

#include "functionelement.h"
class CosineFunctionElement : public FunctionElement
{
public:
    CosineFunctionElement();
    ~CosineFunctionElement();
    std::string toQString();
    bool isNull();
    void AddArgument(FormulaElement *argument);
	double evaluate();
	void getVariableValues(std::vector<variableValue*> *variableValue)
	{
        getArgTwo()->getVariableValues(variableValue);
	}
	bool isFullyGrounded()
	{
        return getArgTwo()->isFullyGrounded();
	}

	bool setVariableValues(std::vector<variableValue*> *variableValue)
	{
        return getArgTwo()->setVariableValues(variableValue);
	}

	

    FormulaElement* simplify();
    FormulaElement* getNewInstance() {
	
	return new CosineFunctionElement();
	}
private:
    FunctionElement* argument;
};

#endif // COSINEFUNCTIONELEMENT_H

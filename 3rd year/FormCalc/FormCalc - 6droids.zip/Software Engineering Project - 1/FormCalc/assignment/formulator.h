#ifndef FORMULATOR
#define FORMULATOR

#include "formulaelement.h"
#include "constantelement.h"
#include "functionelement.h"
#include "variableelement.h"
#include "plusfunctionelement.h"
#include "minusfunctionelement.h"
#include "multiplefunctionelement.h"
#include "dividefunctionelement.h"
#include "sinefunctionelement.h"
#include "cosinefunctionelement.h"
#include "powerfunctionelement.h"
//#include "xmlfilehandling.h"

#endif // FORMULATOR


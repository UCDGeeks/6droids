#include "cosinefunctionelement.h"
#include "constantelement.h"

CosineFunctionElement::CosineFunctionElement()
{
}

CosineFunctionElement::~CosineFunctionElement()
{

}

std::string CosineFunctionElement::toQString()
{
    return "cos(" + getArgTwo()->toQString() + ")";
}
bool CosineFunctionElement::isNull()
{
    return false;
}

void CosineFunctionElement::AddArgument(FormulaElement *argument)
{
    int temp=GetArgument().size();

    if(temp==0)
    {
        FunctionElement::AddArgument(argument);
    }
    else
    {
        printf("canno't enter another argument.\n\n");
    }
}



double CosineFunctionElement::evaluate()
{
    return cos(this->getArgTwo()->evaluate() * (pi /180));
}

FormulaElement* CosineFunctionElement::simplify()
{
    std::string typeRHS(typeid(*(getArgTwo()->simplify())).name());

    if (typeRHS.compare("class ConstantElement") == 0)
    {
        return new ConstantElement(this->evaluate());
    }
    else
    {
        FormulaElement* temp = this->getArgTwo()->simplify();
        CosineFunctionElement* simplifyResult = new CosineFunctionElement();
        simplifyResult->setArgTwo(temp);
        return simplifyResult;
    }
}

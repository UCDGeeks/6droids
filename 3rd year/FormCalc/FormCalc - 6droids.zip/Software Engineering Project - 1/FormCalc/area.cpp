#include "area.h"

area::area()
{

}

area::~area(){

}

QString area::areaCal(QString formulastring,double lowBound, int n, double dx){

    //FormulaElement* formula = FormulaElement::parseFormula(formulastring.toStdString());
    FormulaElement* formula = FormulaElement::parseFormula("X+4");


    double cumSum = 0;
        for (int i=0; i<n; i++)
        {
            double xi = lowBound+i*dx;

            vector<variableValue*> val;
            variableValue v;
            v.variable = "X";
            v.value = xi;
            val.push_back(&v);
            formula->setVariableValues(&val);

            double funValue = formula->evaluate() ;
            double rectangleArea = funValue*dx;
            cumSum += rectangleArea;
        }

        return QString::number(cumSum);
}


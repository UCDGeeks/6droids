/**
*
*Team ~6Droids~
*
*/
#include <iostream>
#include "formcalc_graph.h"
#include "ui_formcalc_graph.h"

using namespace std;

// Global variable declaration:
//double xMin = -10;
//double xMax = 10;
//int in0 = 1;
double a0 = -1;
double b0 = -2;
double a1 = 3;
double b1 = 4;
double fx2_aVal = 1;
double fx2_bVal = 2;
double fx2_cVal = 3;
double fx2_xVal = 2;
double gx2_aVal = -1;
double gx2_bVal = -2;
double gx2_cVal = -3;
double gx2_xVal = -4;

FormCalc_Graph::FormCalc_Graph(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::FormCalc_Graph)
{
    ui->setupUi(this);
    //Graph
    ui->fxgraph1->setChecked(true);
    ui->gxgraph1->setChecked(true);
    ui->a0->setText(QString::number(a0));
    ui->b0->setText(QString::number(b0));
    ui->a1->setText(QString::number(a1));
    ui->b1->setText(QString::number(b1));
    ui->fx2_graph->setChecked(true);
    ui->gx2_graph->setChecked(true);
    ui->fx2_a->setText(QString::number(fx2_aVal));
    ui->fx2_b->setText(QString::number(fx2_bVal));
    ui->fx2_c->setText(QString::number(fx2_cVal));
    ui->fx2_x->setText(QString::number(fx2_xVal));
    ui->gx2_a->setText(QString::number(gx2_aVal));
    ui->gx2_b->setText(QString::number(gx2_bVal));
    ui->gx2_c->setText(QString::number(gx2_cVal));
    ui->gx2_x->setText(QString::number(gx2_xVal));
    setupPlot();
    // configure scroll bars:
    ui->horizontalScrollBar->setRange(-500, 500);
    ui->verticalScrollBar->setRange(-500, 500);

    // create connection between axes and scroll bars:
    connect(ui->horizontalScrollBar, SIGNAL(valueChanged(int)), this, SLOT(horzScrollBarChanged(int)));
    connect(ui->verticalScrollBar, SIGNAL(valueChanged(int)), this, SLOT(vertScrollBarChanged(int)));
    connect(ui->plot->xAxis, SIGNAL(rangeChanged(QCPRange)), this, SLOT(xAxisChanged(QCPRange)));
    connect(ui->plot->yAxis, SIGNAL(rangeChanged(QCPRange)), this, SLOT(yAxisChanged(QCPRange)));

    // initialize axis range (and scroll bar positions via signals we just connected):
    ui->plot->xAxis->setRange(0, 6, Qt::AlignCenter);
    ui->plot->yAxis->setRange(0, 10, Qt::AlignCenter);
}

FormCalc_Graph::~FormCalc_Graph()
{
    delete ui;
}

void FormCalc_Graph::setupPlot()
{
  // Plot setup:
  ui->plot->addGraph();
  ui->plot->graph()->setPen(QPen(Qt::blue));
  ui->plot->graph()->setBrush(QBrush(QColor(0, 0, 255, 20)));
  ui->plot->addGraph();
  ui->plot->graph()->setPen(QPen(Qt::red));
  ui->plot->graph()->setBrush(QBrush(QColor(255,0,0,20)));
  ui->plot->addGraph();
  ui->plot->graph()->setPen(QPen(Qt::green));
  ui->plot->addGraph();
  ui->plot->graph()->setPen(QPen(Qt::yellow));
  QVector<double> x(500), y0(500), y1(500), y2(500), y3(500);
  for (int i=0; i<500; ++i)
  {
    x[i] = (i/499.0-0.5)*10;
    y0[i] = a0* x[i] + (b0);
    y1[i] = a1* x[i] + (b1);
    y2[i] = fx2_aVal* getPowerOfX(x[i], fx2_xVal) + fx2_bVal*x[i] + fx2_cVal;
    y3[i] = gx2_aVal* getPowerOfX(x[i], gx2_xVal) + gx2_bVal*x[i] + gx2_cVal;
  }
  ui->plot->graph(0)->setData(x, y0);
  ui->plot->graph(1)->setData(x, y1);
  ui->plot->graph(2)->setData(x, y2);
  ui->plot->graph(3)->setData(x, y3);
//  ui->plot->graph(0)->setData(fx, fy);
//  ui->plot->graph(1)->setData(gx, gy);
  ui->plot->axisRect()->setupFullAxesBox(true);
  ui->plot->setInteractions(QCP::iRangeDrag | QCP::iRangeZoom);
}

double FormCalc_Graph::getPowerOfX(double value, double xValMax) {
    for(int i =1; i<xValMax; ++i){
        value *= value;
    }
    return value;
}

void FormCalc_Graph::horzScrollBarChanged(int value)
{
  if (qAbs(ui->plot->xAxis->range().center()-value/100.0) > 0.01) // if user is dragging plot, don't want to replot twice
  {
    ui->plot->xAxis->setRange(value/100.0, ui->plot->xAxis->range().size(), Qt::AlignCenter);
    ui->plot->replot();
  }
}

void FormCalc_Graph::vertScrollBarChanged(int value)
{
  if (qAbs(ui->plot->yAxis->range().center()+value/100.0) > 0.01) // if user is dragging plot, don't want to replot twice
  {
    ui->plot->yAxis->setRange(-value/100.0, ui->plot->yAxis->range().size(), Qt::AlignCenter);
    ui->plot->replot();
  }
}

void FormCalc_Graph::xAxisChanged(QCPRange range)
{
  ui->horizontalScrollBar->setValue(qRound(range.center()*100.0)); // adjust position of scroll bar slider
  ui->horizontalScrollBar->setPageStep(qRound(range.size()*100.0)); // adjust size of scroll bar slider
}

void FormCalc_Graph::yAxisChanged(QCPRange range)
{
  ui->verticalScrollBar->setValue(qRound(-range.center()*100.0)); // adjust position of scroll bar slider
  ui->verticalScrollBar->setPageStep(qRound(range.size()*100.0)); // adjust size of scroll bar slider
}

void FormCalc_Graph::on_btn_DrawGraph_clicked()
{
    ui->fxgraph1->setChecked(true);
    ui->gxgraph1->setChecked(true);
    QString fa=ui->a0->text();
    QString fb=ui->b0->text();
    QString ga=ui->a1->text();
    QString gb=ui->b1->text();
    a0 = fa.toDouble();
    b0 = fb.toDouble();
    a1 = ga.toDouble();
    b1 = gb.toDouble();
    setupPlot();
}

void FormCalc_Graph::on_fxgraph1_clicked(bool checked)
{
    if(checked){
        QString fa=ui->a0->text();
        QString fb=ui->b0->text();
        a0 = fa.toDouble();
        b0 = fb.toDouble();
        setupPlot();
    }else{
        ui->a0->setText("0");
        ui->b0->setText("0");
        a0 = 0;
        b0 = 0;
        setupPlot();
    }

}

void FormCalc_Graph::on_gxgraph1_clicked(bool checked)
{
    if(checked){
        QString ga=ui->a1->text();
        QString gb=ui->b1->text();
        a1 = ga.toDouble();
        b1 = gb.toDouble();
        setupPlot();
    }else{
        ui->a1->setText("0");
        ui->b1->setText("0");
        a1 = 0;
        b1 = 0;
        setupPlot();
    }
}

void FormCalc_Graph::on_btn_DrawGraph_2_clicked()
{
    ui->fx2_graph->setChecked(true);
    ui->gx2_graph->setChecked(true);
    QString fx2_a=ui->fx2_a->text();
    QString fx2_b=ui->fx2_b->text();
    QString fx2_c=ui->fx2_c->text();
    QString fx2_x=ui->fx2_x->text();
    fx2_aVal = fx2_a.toDouble();
    fx2_bVal = fx2_b.toDouble();
    fx2_cVal = fx2_c.toDouble();
    fx2_xVal = fx2_x.toDouble();
    setupPlot();
    QString gx2_a=ui->gx2_a->text();
    QString gx2_b=ui->gx2_b->text();
    QString gx2_c=ui->gx2_c->text();
    QString gx2_x=ui->gx2_x->text();
    gx2_aVal = gx2_a.toDouble();
    gx2_bVal = gx2_b.toDouble();
    gx2_cVal = gx2_c.toDouble();
    gx2_xVal = gx2_x.toDouble();
    setupPlot();
}

void FormCalc_Graph::on_fx2_graph_clicked(bool checked)
{
    if(checked){
        QString fx2_a=ui->fx2_a->text();
        QString fx2_b=ui->fx2_b->text();
        QString fx2_c=ui->fx2_c->text();
        QString fx2_x=ui->fx2_x->text();
        fx2_aVal = fx2_a.toDouble();
        fx2_bVal = fx2_b.toDouble();
        fx2_cVal = fx2_c.toDouble();
        fx2_xVal = fx2_x.toDouble();
        setupPlot();
    }else{
        ui->fx2_a->setText("0");
        ui->fx2_b->setText("0");
        ui->fx2_c->setText("0");
        ui->fx2_x->setText("0");
        fx2_aVal = 0;
        fx2_bVal = 0;
        fx2_cVal = 0;
        fx2_xVal = 0;
        setupPlot();
    }
}

void FormCalc_Graph::on_gx2_graph_clicked(bool checked)
{
    if(checked){
        QString gx2_a=ui->gx2_a->text();
        QString gx2_b=ui->gx2_b->text();
        QString gx2_c=ui->gx2_c->text();
        QString gx2_x=ui->gx2_x->text();
        gx2_aVal = gx2_a.toDouble();
        gx2_bVal = gx2_b.toDouble();
        gx2_cVal = gx2_c.toDouble();
        gx2_xVal = gx2_x.toDouble();
        setupPlot();
    }else{
        ui->gx2_a->setText("0");
        ui->gx2_b->setText("0");
        ui->gx2_c->setText("0");
        ui->gx2_x->setText("0");
        gx2_aVal = 0;
        gx2_bVal = 0;
        gx2_cVal = 0;
        gx2_xVal = 0;
        setupPlot();
    }
}


void FormCalc_Graph::on_save_btn_clicked()
{
    QString saveImagePath = QFileDialog::getSaveFileName(this, tr("Save Graph"),"./untitled.png", tr("Image file (*.png)"));
    std::string strSaveFilePath = saveImagePath.toLocal8Bit().constData();

    ui->plot->savePng( &strSaveFilePath[0], 0, 0, 1.0, -1 );
}

void FormCalc_Graph::on_pushButton_6_clicked()
{
    QString formula = ui->lineEdit_7->text();
    QString min = ui->min_text->text();
    QString max = ui->max_txt->text();

    area a;
    ui->area_txt->setText( a.areaCal(formula, min.toDouble(), 1000, max.toDouble() ) );


}

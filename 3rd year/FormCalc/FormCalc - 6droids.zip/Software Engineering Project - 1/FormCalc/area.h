#ifndef AREA_H
#define AREA_H

#include <QString>
#include "assignment/formulaelement.h"

using namespace std;

class area
{
public:
    area();
    ~area();
    QString areaCal(QString formula,double lowBound, int n, double dx);
};

#endif // AREA_H

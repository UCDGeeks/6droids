/**
*
*Team ~6Droids~
*
*/

#ifndef MAINWINDOW_H
#define MAINWINDOW_H

//#include <QMainWindow>
#include <QWidget>
//#include "formcalc_advance.h"
//#include "formcalc_scientific.h"
#include "dependencies.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QWidget
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

    //added
        private slots:
           //void openNewWindow();
            //window switching
            void on_scientific_btn_clicked();
            void on_advance_btn_clicked();
            void on_graph_btn_clicked();
            //-END-window switching

            //numpad slots
            void on_zero_btn_clicked();
            void on_one_btn_clicked();
            void on_two_btn_clicked();
            void on_three_btn_clicked();
            void on_four_btn_clicked();
            void on_five_btn_clicked();
            void on_six_btn_clicked();
            void on_seven_btn_clicked();
            void on_eight_btn_clicked();
            void on_nine_btn_clicked();
            void on_dot_btn_clicked();
            void on_plus_btn_clicked();
            void on_min_btn_clicked();
            void on_multiply_btn_clicked();
            void on_divide_btn_clicked();
            //-END-numpad slots

            void on_c_btn_clicked();
            void on_ce_btn_clicked();
            void on_plusormin_btn_clicked();
            void on_del_btn_clicked();

private:
        /*Formcalc_advance *advance;
        FormCalc_Scientific *scientific;*/
           void appenedin(QString totalline);
           void notempty_appenedin(QString formularline);



        Ui::MainWindow *ui;



/* private slots:
    void on_scientific_btn_clicked(); */

/* private:
    Ui::MainWindow *ui; */
};

#endif // MAINWINDOW_H

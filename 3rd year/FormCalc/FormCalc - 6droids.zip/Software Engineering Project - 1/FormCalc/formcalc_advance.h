/**
*
*Team ~6Droids~
*
*/

#ifndef FORMCALC_ADVANCE_H
#define FORMCALC_ADVANCE_H

#include <QWidget>
#include "dependencies.h"

namespace Ui {
class Formcalc_advance;
}

class Formcalc_advance : public QWidget
{
    Q_OBJECT

public:
    explicit Formcalc_advance(QWidget *parent = 0);
    ~Formcalc_advance();

private:
    Ui::Formcalc_advance *ui;

private slots:

};

#endif // FORMCALC_ADVANCE_H

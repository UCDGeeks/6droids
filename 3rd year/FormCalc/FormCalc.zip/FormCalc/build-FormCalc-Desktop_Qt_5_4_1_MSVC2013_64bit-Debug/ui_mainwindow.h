/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.4.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *FormCalccenter;
    QLineEdit *formular_txtline;
    QLineEdit *total_txtline;
    QLineEdit *prvtotal_txtline;
    QPushButton *basic_btn;
    QPushButton *scientific_btn;
    QPushButton *advance_btn;
    QPushButton *graph_btn;
    QPushButton *mc_btn;
    QPushButton *mr_btn;
    QPushButton *ms_btn;
    QPushButton *mplus_btn;
    QPushButton *mminus_btn;
    QPushButton *del_btn;
    QPushButton *seven_btn;
    QPushButton *four_btn;
    QPushButton *one_btn;
    QPushButton *zero_btn;
    QPushButton *ce_btn;
    QPushButton *five_btn;
    QPushButton *two_btn;
    QPushButton *c_btn;
    QPushButton *nine_btn;
    QPushButton *six_btn;
    QPushButton *three_btn;
    QPushButton *dot_btn;
    QPushButton *plusormin_btn;
    QPushButton *divide_btn;
    QPushButton *multiply_btn;
    QPushButton *min_btn;
    QPushButton *plus_btn;
    QPushButton *root_btn;
    QPushButton *precentage_btn;
    QPushButton *reciprocal_btn;
    QPushButton *equal_btn;
    QComboBox *history_combo;
    QPushButton *eight_btn;

    void setupUi(QWidget *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(400, 500);
        MainWindow->setMinimumSize(QSize(400, 500));
        MainWindow->setMaximumSize(QSize(400, 520));
        MainWindow->setCursor(QCursor(Qt::ArrowCursor));
        MainWindow->setFocusPolicy(Qt::StrongFocus);
        QIcon icon;
        icon.addFile(QStringLiteral(":/icon/window_icon_2.png"), QSize(), QIcon::Normal, QIcon::Off);
        MainWindow->setWindowIcon(icon);
        MainWindow->setWindowOpacity(1);
        MainWindow->setStyleSheet(QLatin1String("#basic_btn {\n"
"	color:white;\n"
"	background-color:#5a5959;\n"
"}"));
        MainWindow->setProperty("iconSize", QVariant(QSize(24, 24)));
        FormCalccenter = new QWidget(MainWindow);
        FormCalccenter->setObjectName(QStringLiteral("FormCalccenter"));
        FormCalccenter->setGeometry(QRect(0, 0, 401, 501));
        FormCalccenter->setStyleSheet(QStringLiteral("background:#909090;"));
        formular_txtline = new QLineEdit(FormCalccenter);
        formular_txtline->setObjectName(QStringLiteral("formular_txtline"));
        formular_txtline->setGeometry(QRect(0, 0, 401, 20));
        QFont font;
        font.setFamily(QStringLiteral("Segoe UI"));
        font.setPointSize(10);
        formular_txtline->setFont(font);
        formular_txtline->setLayoutDirection(Qt::RightToLeft);
        formular_txtline->setStyleSheet(QLatin1String("#formular_txtline{\n"
"color:#585858;\n"
"background:#e0e0e0;\n"
"}"));
        formular_txtline->setInputMethodHints(Qt::ImhDialableCharactersOnly|Qt::ImhDigitsOnly|Qt::ImhPreferNumbers);
        formular_txtline->setFrame(false);
        formular_txtline->setCursorPosition(0);
        formular_txtline->setAlignment(Qt::AlignBottom|Qt::AlignRight|Qt::AlignTrailing);
        formular_txtline->setReadOnly(true);
        formular_txtline->setClearButtonEnabled(false);
        total_txtline = new QLineEdit(FormCalccenter);
        total_txtline->setObjectName(QStringLiteral("total_txtline"));
        total_txtline->setGeometry(QRect(0, 20, 401, 41));
        QFont font1;
        font1.setFamily(QStringLiteral("Segoe UI"));
        font1.setPointSize(15);
        font1.setBold(true);
        font1.setWeight(75);
        total_txtline->setFont(font1);
        total_txtline->setLayoutDirection(Qt::RightToLeft);
        total_txtline->setAutoFillBackground(false);
        total_txtline->setStyleSheet(QLatin1String("#total_txtline{\n"
"color:#000000;\n"
"background:#e0e0e0;\n"
"}"));
        total_txtline->setInputMethodHints(Qt::ImhDialableCharactersOnly|Qt::ImhDigitsOnly);
        total_txtline->setFrame(false);
        total_txtline->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        total_txtline->setReadOnly(false);
        total_txtline->setClearButtonEnabled(false);
        prvtotal_txtline = new QLineEdit(FormCalccenter);
        prvtotal_txtline->setObjectName(QStringLiteral("prvtotal_txtline"));
        prvtotal_txtline->setGeometry(QRect(0, 60, 401, 21));
        prvtotal_txtline->setFont(font);
        prvtotal_txtline->setLayoutDirection(Qt::RightToLeft);
        prvtotal_txtline->setStyleSheet(QLatin1String("#prvtotal_txtline{\n"
"color: #585858;\n"
"background:#e0e0e0;\n"
"}"));
        prvtotal_txtline->setInputMethodHints(Qt::ImhDialableCharactersOnly|Qt::ImhDigitsOnly);
        prvtotal_txtline->setFrame(false);
        prvtotal_txtline->setAlignment(Qt::AlignRight|Qt::AlignTop|Qt::AlignTrailing);
        prvtotal_txtline->setReadOnly(true);
        prvtotal_txtline->setClearButtonEnabled(false);
        basic_btn = new QPushButton(FormCalccenter);
        basic_btn->setObjectName(QStringLiteral("basic_btn"));
        basic_btn->setGeometry(QRect(0, 80, 101, 51));
        QFont font2;
        font2.setFamily(QStringLiteral("Segoe UI"));
        font2.setPointSize(15);
        font2.setBold(false);
        font2.setWeight(50);
        basic_btn->setFont(font2);
        basic_btn->setCursor(QCursor(Qt::PointingHandCursor));
        basic_btn->setAutoFillBackground(false);
        basic_btn->setStyleSheet(QLatin1String("QPushButton{	color:white;\n"
"	background-color: #de8769;\n"
"	\n"
"	\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;} \n"
"\n"
"/*\n"
"border-top-left-radius: 20px;\n"
"	border-bottom-left-radius: 20px;\n"
"*/\n"
"\n"
""));
        basic_btn->setCheckable(false);
        basic_btn->setChecked(false);
        basic_btn->setDefault(false);
        basic_btn->setFlat(false);
        scientific_btn = new QPushButton(FormCalccenter);
        scientific_btn->setObjectName(QStringLiteral("scientific_btn"));
        scientific_btn->setGeometry(QRect(100, 80, 101, 51));
        scientific_btn->setFont(font2);
        scientific_btn->setCursor(QCursor(Qt::PointingHandCursor));
        scientific_btn->setAutoFillBackground(false);
        scientific_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        scientific_btn->setFlat(true);
        advance_btn = new QPushButton(FormCalccenter);
        advance_btn->setObjectName(QStringLiteral("advance_btn"));
        advance_btn->setGeometry(QRect(200, 80, 101, 51));
        advance_btn->setFont(font2);
        advance_btn->setCursor(QCursor(Qt::PointingHandCursor));
        advance_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        advance_btn->setFlat(true);
        graph_btn = new QPushButton(FormCalccenter);
        graph_btn->setObjectName(QStringLiteral("graph_btn"));
        graph_btn->setGeometry(QRect(300, 80, 101, 51));
        graph_btn->setFont(font2);
        graph_btn->setCursor(QCursor(Qt::PointingHandCursor));
        graph_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;\n"
"\n"
"/*\n"
"	border-top-right-radius: 20px;\n"
"	border-bottom-right-radius: 20px;\n"
"*/"));
        graph_btn->setFlat(true);
        mc_btn = new QPushButton(FormCalccenter);
        mc_btn->setObjectName(QStringLiteral("mc_btn"));
        mc_btn->setGeometry(QRect(0, 140, 81, 51));
        mc_btn->setFont(font2);
        mc_btn->setCursor(QCursor(Qt::PointingHandCursor));
        mc_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        mc_btn->setFlat(true);
        mr_btn = new QPushButton(FormCalccenter);
        mr_btn->setObjectName(QStringLiteral("mr_btn"));
        mr_btn->setGeometry(QRect(80, 140, 81, 51));
        mr_btn->setFont(font2);
        mr_btn->setCursor(QCursor(Qt::PointingHandCursor));
        mr_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        mr_btn->setFlat(true);
        ms_btn = new QPushButton(FormCalccenter);
        ms_btn->setObjectName(QStringLiteral("ms_btn"));
        ms_btn->setGeometry(QRect(160, 140, 81, 51));
        ms_btn->setFont(font2);
        ms_btn->setCursor(QCursor(Qt::PointingHandCursor));
        ms_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        ms_btn->setFlat(true);
        mplus_btn = new QPushButton(FormCalccenter);
        mplus_btn->setObjectName(QStringLiteral("mplus_btn"));
        mplus_btn->setGeometry(QRect(240, 140, 81, 51));
        mplus_btn->setFont(font2);
        mplus_btn->setCursor(QCursor(Qt::PointingHandCursor));
        mplus_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        mplus_btn->setFlat(true);
        mminus_btn = new QPushButton(FormCalccenter);
        mminus_btn->setObjectName(QStringLiteral("mminus_btn"));
        mminus_btn->setGeometry(QRect(320, 140, 81, 51));
        mminus_btn->setFont(font2);
        mminus_btn->setCursor(QCursor(Qt::PointingHandCursor));
        mminus_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        mminus_btn->setFlat(true);
        del_btn = new QPushButton(FormCalccenter);
        del_btn->setObjectName(QStringLiteral("del_btn"));
        del_btn->setGeometry(QRect(0, 190, 81, 51));
        QFont font3;
        font3.setFamily(QStringLiteral("Segoe UI"));
        font3.setPointSize(25);
        font3.setBold(false);
        font3.setWeight(50);
        del_btn->setFont(font3);
        del_btn->setCursor(QCursor(Qt::PointingHandCursor));
        del_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        del_btn->setFlat(true);
        seven_btn = new QPushButton(FormCalccenter);
        seven_btn->setObjectName(QStringLiteral("seven_btn"));
        seven_btn->setGeometry(QRect(0, 240, 81, 51));
        seven_btn->setFont(font1);
        seven_btn->setCursor(QCursor(Qt::PointingHandCursor));
        seven_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #cacaca;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        seven_btn->setFlat(true);
        four_btn = new QPushButton(FormCalccenter);
        four_btn->setObjectName(QStringLiteral("four_btn"));
        four_btn->setGeometry(QRect(0, 290, 81, 51));
        four_btn->setFont(font1);
        four_btn->setCursor(QCursor(Qt::PointingHandCursor));
        four_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #cacaca;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        four_btn->setFlat(true);
        one_btn = new QPushButton(FormCalccenter);
        one_btn->setObjectName(QStringLiteral("one_btn"));
        one_btn->setGeometry(QRect(0, 340, 81, 51));
        one_btn->setFont(font1);
        one_btn->setCursor(QCursor(Qt::PointingHandCursor));
        one_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #cacaca;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        one_btn->setFlat(true);
        zero_btn = new QPushButton(FormCalccenter);
        zero_btn->setObjectName(QStringLiteral("zero_btn"));
        zero_btn->setGeometry(QRect(0, 390, 161, 50));
        zero_btn->setFont(font1);
        zero_btn->setCursor(QCursor(Qt::PointingHandCursor));
        zero_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #cacaca;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        zero_btn->setFlat(true);
        ce_btn = new QPushButton(FormCalccenter);
        ce_btn->setObjectName(QStringLiteral("ce_btn"));
        ce_btn->setGeometry(QRect(80, 190, 81, 51));
        ce_btn->setFont(font2);
        ce_btn->setCursor(QCursor(Qt::PointingHandCursor));
        ce_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        ce_btn->setFlat(true);
        five_btn = new QPushButton(FormCalccenter);
        five_btn->setObjectName(QStringLiteral("five_btn"));
        five_btn->setGeometry(QRect(80, 290, 81, 51));
        five_btn->setFont(font1);
        five_btn->setCursor(QCursor(Qt::PointingHandCursor));
        five_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #cacaca;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        five_btn->setFlat(true);
        two_btn = new QPushButton(FormCalccenter);
        two_btn->setObjectName(QStringLiteral("two_btn"));
        two_btn->setGeometry(QRect(80, 340, 81, 51));
        two_btn->setFont(font1);
        two_btn->setCursor(QCursor(Qt::PointingHandCursor));
        two_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #cacaca;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        two_btn->setFlat(true);
        c_btn = new QPushButton(FormCalccenter);
        c_btn->setObjectName(QStringLiteral("c_btn"));
        c_btn->setGeometry(QRect(160, 190, 81, 51));
        c_btn->setFont(font2);
        c_btn->setCursor(QCursor(Qt::PointingHandCursor));
        c_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        c_btn->setFlat(true);
        nine_btn = new QPushButton(FormCalccenter);
        nine_btn->setObjectName(QStringLiteral("nine_btn"));
        nine_btn->setGeometry(QRect(160, 240, 81, 51));
        nine_btn->setFont(font1);
        nine_btn->setCursor(QCursor(Qt::PointingHandCursor));
        nine_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #cacaca;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        nine_btn->setFlat(true);
        six_btn = new QPushButton(FormCalccenter);
        six_btn->setObjectName(QStringLiteral("six_btn"));
        six_btn->setGeometry(QRect(160, 290, 81, 51));
        six_btn->setFont(font1);
        six_btn->setCursor(QCursor(Qt::PointingHandCursor));
        six_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #cacaca;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        six_btn->setFlat(true);
        three_btn = new QPushButton(FormCalccenter);
        three_btn->setObjectName(QStringLiteral("three_btn"));
        three_btn->setGeometry(QRect(160, 340, 81, 51));
        three_btn->setFont(font1);
        three_btn->setCursor(QCursor(Qt::PointingHandCursor));
        three_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #cacaca;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        three_btn->setFlat(true);
        dot_btn = new QPushButton(FormCalccenter);
        dot_btn->setObjectName(QStringLiteral("dot_btn"));
        dot_btn->setGeometry(QRect(160, 390, 81, 50));
        dot_btn->setFont(font3);
        dot_btn->setCursor(QCursor(Qt::PointingHandCursor));
        dot_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #cacaca;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        dot_btn->setFlat(true);
        plusormin_btn = new QPushButton(FormCalccenter);
        plusormin_btn->setObjectName(QStringLiteral("plusormin_btn"));
        plusormin_btn->setGeometry(QRect(240, 190, 81, 51));
        QFont font4;
        font4.setFamily(QStringLiteral("Segoe UI"));
        font4.setPointSize(20);
        font4.setBold(false);
        font4.setWeight(50);
        plusormin_btn->setFont(font4);
        plusormin_btn->setCursor(QCursor(Qt::PointingHandCursor));
        plusormin_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        plusormin_btn->setFlat(true);
        divide_btn = new QPushButton(FormCalccenter);
        divide_btn->setObjectName(QStringLiteral("divide_btn"));
        divide_btn->setGeometry(QRect(240, 240, 81, 51));
        divide_btn->setFont(font4);
        divide_btn->setCursor(QCursor(Qt::PointingHandCursor));
        divide_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #f4d16a;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        divide_btn->setFlat(true);
        multiply_btn = new QPushButton(FormCalccenter);
        multiply_btn->setObjectName(QStringLiteral("multiply_btn"));
        multiply_btn->setGeometry(QRect(240, 290, 81, 51));
        multiply_btn->setFont(font4);
        multiply_btn->setCursor(QCursor(Qt::PointingHandCursor));
        multiply_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #f4d16a;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        multiply_btn->setFlat(true);
        min_btn = new QPushButton(FormCalccenter);
        min_btn->setObjectName(QStringLiteral("min_btn"));
        min_btn->setGeometry(QRect(240, 340, 81, 51));
        min_btn->setFont(font4);
        min_btn->setCursor(QCursor(Qt::PointingHandCursor));
        min_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #f4d16a;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        min_btn->setFlat(true);
        plus_btn = new QPushButton(FormCalccenter);
        plus_btn->setObjectName(QStringLiteral("plus_btn"));
        plus_btn->setGeometry(QRect(240, 390, 81, 50));
        plus_btn->setFont(font4);
        plus_btn->setCursor(QCursor(Qt::PointingHandCursor));
        plus_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #f4d16a;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        plus_btn->setFlat(true);
        root_btn = new QPushButton(FormCalccenter);
        root_btn->setObjectName(QStringLiteral("root_btn"));
        root_btn->setGeometry(QRect(320, 190, 80, 51));
        root_btn->setFont(font2);
        root_btn->setCursor(QCursor(Qt::PointingHandCursor));
        root_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        root_btn->setFlat(true);
        precentage_btn = new QPushButton(FormCalccenter);
        precentage_btn->setObjectName(QStringLiteral("precentage_btn"));
        precentage_btn->setGeometry(QRect(320, 240, 80, 51));
        precentage_btn->setFont(font2);
        precentage_btn->setCursor(QCursor(Qt::PointingHandCursor));
        precentage_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        precentage_btn->setFlat(true);
        reciprocal_btn = new QPushButton(FormCalccenter);
        reciprocal_btn->setObjectName(QStringLiteral("reciprocal_btn"));
        reciprocal_btn->setGeometry(QRect(320, 290, 80, 51));
        reciprocal_btn->setFont(font2);
        reciprocal_btn->setCursor(QCursor(Qt::PointingHandCursor));
        reciprocal_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        reciprocal_btn->setFlat(true);
        equal_btn = new QPushButton(FormCalccenter);
        equal_btn->setObjectName(QStringLiteral("equal_btn"));
        equal_btn->setGeometry(QRect(320, 340, 80, 100));
        equal_btn->setFont(font4);
        equal_btn->setCursor(QCursor(Qt::PointingHandCursor));
        equal_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #69c86f;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        equal_btn->setFlat(true);
        history_combo = new QComboBox(FormCalccenter);
        history_combo->setObjectName(QStringLiteral("history_combo"));
        history_combo->setGeometry(QRect(0, 440, 401, 61));
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(history_combo->sizePolicy().hasHeightForWidth());
        history_combo->setSizePolicy(sizePolicy);
        QFont font5;
        font5.setFamily(QStringLiteral("Segoe UI"));
        font5.setPointSize(20);
        font5.setBold(true);
        font5.setWeight(75);
        history_combo->setFont(font5);
        history_combo->setCursor(QCursor(Qt::PointingHandCursor));
        history_combo->setStyleSheet(QLatin1String("QComboBox{	\n"
"	outline:none;\n"
"	color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 0px;\n"
"	border-radius:15px;\n"
"	border-color:#909090;\n"
"}\n"
" QComboBox::down-arrow {\n"
"    border-image:url(C:/Users/Sahitha Nelanga/Desktop/FormCalc/Project/FormCalc/GitLab/FormCalc/arrow.png);\n"
"	position: center;\n"
"	width: 16;\n"
"	height: 16;\n"
"    }\n"
"\n"
"QComboBox::drop-down {\n"
"width: 16px;\n"
"border-top-right-radius: 3px;\n"
"border-bottom-right-radius: 3px;\n"
"}\n"
"\n"
"QComboBox::down-arrow:on {\n"
"  	border-image:url(C:/Users/Sahitha Nelanga/Desktop/FormCalc/Project/FormCalc/GitLab/FormCalc/arrowup.png);\n"
"	position: center;\n"
"	width: 16;\n"
"	height: 16\n"
" }"));
        history_combo->setEditable(false);
        history_combo->setIconSize(QSize(50, 50));
        history_combo->setDuplicatesEnabled(false);
        history_combo->setFrame(false);
        eight_btn = new QPushButton(FormCalccenter);
        eight_btn->setObjectName(QStringLiteral("eight_btn"));
        eight_btn->setGeometry(QRect(80, 240, 81, 51));
        eight_btn->setFont(font1);
        eight_btn->setCursor(QCursor(Qt::PointingHandCursor));
        eight_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #cacaca;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        eight_btn->setFlat(true);
        formular_txtline->raise();
        total_txtline->raise();
        prvtotal_txtline->raise();
        basic_btn->raise();
        scientific_btn->raise();
        advance_btn->raise();
        graph_btn->raise();
        mc_btn->raise();
        mr_btn->raise();
        ms_btn->raise();
        mplus_btn->raise();
        mminus_btn->raise();
        del_btn->raise();
        seven_btn->raise();
        four_btn->raise();
        one_btn->raise();
        zero_btn->raise();
        ce_btn->raise();
        two_btn->raise();
        c_btn->raise();
        nine_btn->raise();
        six_btn->raise();
        three_btn->raise();
        dot_btn->raise();
        plusormin_btn->raise();
        divide_btn->raise();
        multiply_btn->raise();
        min_btn->raise();
        plus_btn->raise();
        root_btn->raise();
        precentage_btn->raise();
        reciprocal_btn->raise();
        equal_btn->raise();
        history_combo->raise();
        eight_btn->raise();
        five_btn->raise();

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QWidget *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "FormCalc - Basic", 0));
#ifndef QT_NO_TOOLTIP
        formular_txtline->setToolTip(QString());
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_TOOLTIP
        total_txtline->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        total_txtline->setInputMask(QString());
        total_txtline->setText(QString());
#ifndef QT_NO_TOOLTIP
        prvtotal_txtline->setToolTip(QString());
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_TOOLTIP
        basic_btn->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        basic_btn->setText(QApplication::translate("MainWindow", "Basic", 0));
#ifndef QT_NO_TOOLTIP
        scientific_btn->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        scientific_btn->setText(QApplication::translate("MainWindow", "Scientific", 0));
#ifndef QT_NO_TOOLTIP
        advance_btn->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        advance_btn->setText(QApplication::translate("MainWindow", "Advance", 0));
#ifndef QT_NO_TOOLTIP
        graph_btn->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        graph_btn->setText(QApplication::translate("MainWindow", "Graph", 0));
        mc_btn->setText(QApplication::translate("MainWindow", "MC", 0));
        mr_btn->setText(QApplication::translate("MainWindow", "MR", 0));
        ms_btn->setText(QApplication::translate("MainWindow", "MS", 0));
        mplus_btn->setText(QApplication::translate("MainWindow", "M+", 0));
        mminus_btn->setText(QApplication::translate("MainWindow", "M-", 0));
        del_btn->setText(QApplication::translate("MainWindow", "\342\206\220", 0));
        seven_btn->setText(QApplication::translate("MainWindow", "7", 0));
        four_btn->setText(QApplication::translate("MainWindow", "4", 0));
        one_btn->setText(QApplication::translate("MainWindow", "1", 0));
        zero_btn->setText(QApplication::translate("MainWindow", "0", 0));
        ce_btn->setText(QApplication::translate("MainWindow", "CE", 0));
        five_btn->setText(QApplication::translate("MainWindow", "5", 0));
        two_btn->setText(QApplication::translate("MainWindow", "2", 0));
        c_btn->setText(QApplication::translate("MainWindow", "C", 0));
        nine_btn->setText(QApplication::translate("MainWindow", "9", 0));
        six_btn->setText(QApplication::translate("MainWindow", "6", 0));
        three_btn->setText(QApplication::translate("MainWindow", "3", 0));
        dot_btn->setText(QApplication::translate("MainWindow", ".", 0));
        plusormin_btn->setText(QApplication::translate("MainWindow", "\302\261", 0));
        divide_btn->setText(QApplication::translate("MainWindow", "\303\267", 0));
        multiply_btn->setText(QApplication::translate("MainWindow", "x", 0));
        min_btn->setText(QApplication::translate("MainWindow", "-", 0));
        plus_btn->setText(QApplication::translate("MainWindow", "+", 0));
        root_btn->setText(QApplication::translate("MainWindow", "\342\210\232", 0));
        precentage_btn->setText(QApplication::translate("MainWindow", "%", 0));
        reciprocal_btn->setText(QApplication::translate("MainWindow", "1/x", 0));
        equal_btn->setText(QApplication::translate("MainWindow", "=", 0));
        history_combo->clear();
        history_combo->insertItems(0, QStringList()
         << QApplication::translate("MainWindow", "History", 0)
        );
        eight_btn->setText(QApplication::translate("MainWindow", "8", 0));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H

/********************************************************************************
** Form generated from reading UI file 'formcalc_advance.ui'
**
** Created by: Qt User Interface Compiler version 5.4.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FORMCALC_ADVANCE_H
#define UI_FORMCALC_ADVANCE_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Formcalc_advance
{
public:
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *graph_btn;
    QPushButton *advance_btn;
    QPushButton *scientific_btn;
    QPushButton *basic_btn;
    QComboBox *comboBox;
    QFrame *line;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLineEdit *lineEdit;
    QLineEdit *lineEdit_2;
    QPushButton *pushButton_7;
    QPushButton *pushButton_8;
    QLabel *label_5;
    QLabel *label_6;
    QLineEdit *lineEdit_3;
    QLineEdit *lineEdit_4;
    QLabel *label_7;
    QLabel *label_8;

    void setupUi(QWidget *Formcalc_advance)
    {
        if (Formcalc_advance->objectName().isEmpty())
            Formcalc_advance->setObjectName(QStringLiteral("Formcalc_advance"));
        Formcalc_advance->resize(810, 600);
        Formcalc_advance->setMinimumSize(QSize(810, 600));
        Formcalc_advance->setMaximumSize(QSize(810, 600));
        QFont font;
        font.setFamily(QStringLiteral("Segoe UI"));
        font.setPointSize(15);
        Formcalc_advance->setFont(font);
        Formcalc_advance->setCursor(QCursor(Qt::ArrowCursor));
        QIcon icon;
        icon.addFile(QStringLiteral(":/icon/window_icon_2.png"), QSize(), QIcon::Normal, QIcon::Off);
        Formcalc_advance->setWindowIcon(icon);
        Formcalc_advance->setStyleSheet(QStringLiteral("background:#909090;"));
        pushButton = new QPushButton(Formcalc_advance);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(80, 0, 101, 51));
        pushButton->setFont(font);
        pushButton->setCursor(QCursor(Qt::PointingHandCursor));
        pushButton->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-radius: 30px;\n"
"\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        pushButton->setFlat(true);
        pushButton_2 = new QPushButton(Formcalc_advance);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(180, 0, 101, 51));
        pushButton_2->setFont(font);
        pushButton_2->setCursor(QCursor(Qt::PointingHandCursor));
        pushButton_2->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-top-right-radius: 30px;\n"
"	border-bottom-right-radius: 30px;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        pushButton_2->setFlat(true);
        graph_btn = new QPushButton(Formcalc_advance);
        graph_btn->setObjectName(QStringLiteral("graph_btn"));
        graph_btn->setGeometry(QRect(710, 0, 101, 51));
        graph_btn->setFont(font);
        graph_btn->setCursor(QCursor(Qt::PointingHandCursor));
        graph_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        graph_btn->setFlat(true);
        advance_btn = new QPushButton(Formcalc_advance);
        advance_btn->setObjectName(QStringLiteral("advance_btn"));
        advance_btn->setGeometry(QRect(610, 0, 101, 51));
        advance_btn->setFont(font);
        advance_btn->setCursor(QCursor(Qt::PointingHandCursor));
        advance_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #d08a71;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        advance_btn->setAutoDefault(false);
        advance_btn->setDefault(true);
        advance_btn->setFlat(true);
        scientific_btn = new QPushButton(Formcalc_advance);
        scientific_btn->setObjectName(QStringLiteral("scientific_btn"));
        scientific_btn->setGeometry(QRect(510, 0, 101, 51));
        scientific_btn->setFont(font);
        scientific_btn->setCursor(QCursor(Qt::PointingHandCursor));
        scientific_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        scientific_btn->setFlat(true);
        basic_btn = new QPushButton(Formcalc_advance);
        basic_btn->setObjectName(QStringLiteral("basic_btn"));
        basic_btn->setGeometry(QRect(410, 0, 101, 51));
        basic_btn->setFont(font);
        basic_btn->setCursor(QCursor(Qt::PointingHandCursor));
        basic_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        basic_btn->setFlat(true);
        comboBox = new QComboBox(Formcalc_advance);
        comboBox->setObjectName(QStringLiteral("comboBox"));
        comboBox->setGeometry(QRect(210, 530, 381, 61));
        QFont font1;
        font1.setPointSize(20);
        comboBox->setFont(font1);
        comboBox->setStyleSheet(QLatin1String("QComboBox{	\n"
"	outline:none;\n"
"	color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 0px;\n"
"	border-radius:15px;\n"
"	border-color:#909090;\n"
"}\n"
" QComboBox::down-arrow {\n"
"    border-image:url(C:/Users/Sahitha Nelanga/Desktop/FormCalc/Project/FormCalc/GitLab/FormCalc/arrow.png);\n"
"	position: center;\n"
"	width: 16;\n"
"	height: 16;\n"
"    }\n"
"\n"
"QComboBox::drop-down {\n"
"width: 16px;\n"
"border-top-right-radius: 3px;\n"
"border-bottom-right-radius: 3px;\n"
"}\n"
"\n"
"QComboBox::down-arrow:on {\n"
"  	border-image:url(C:/Users/Sahitha Nelanga/Desktop/FormCalc/Project/FormCalc/GitLab/FormCalc/arrowup.png);\n"
"	position: center;\n"
"	width: 16;\n"
"	height: 16\n"
" }"));
        line = new QFrame(Formcalc_advance);
        line->setObjectName(QStringLiteral("line"));
        line->setGeometry(QRect(380, 60, 41, 461));
        line->setBaseSize(QSize(0, 0));
        line->setFrameShadow(QFrame::Plain);
        line->setLineWidth(2);
        line->setFrameShape(QFrame::VLine);
        label = new QLabel(Formcalc_advance);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(10, 60, 210, 20));
        QFont font2;
        font2.setPointSize(12);
        font2.setBold(true);
        font2.setWeight(75);
        label->setFont(font2);
        label->setStyleSheet(QStringLiteral("color:white;"));
        label_2 = new QLabel(Formcalc_advance);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(420, 60, 180, 21));
        label_2->setFont(font2);
        label_2->setStyleSheet(QStringLiteral("color:white;"));
        label_3 = new QLabel(Formcalc_advance);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(10, 80, 161, 31));
        QFont font3;
        font3.setFamily(QStringLiteral("Segoe UI"));
        font3.setPointSize(12);
        font3.setBold(true);
        font3.setWeight(75);
        label_3->setFont(font3);
        label_3->setStyleSheet(QStringLiteral("color:white;"));
        label_4 = new QLabel(Formcalc_advance);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(420, 80, 91, 31));
        label_4->setFont(font3);
        label_4->setStyleSheet(QStringLiteral("color:white;"));
        lineEdit = new QLineEdit(Formcalc_advance);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));
        lineEdit->setGeometry(QRect(10, 110, 371, 21));
        QFont font4;
        font4.setFamily(QStringLiteral("Segoe UI"));
        font4.setPointSize(8);
        lineEdit->setFont(font4);
        lineEdit->setStyleSheet(QLatin1String("color: #585858;\n"
"background:#e0e0e0;"));
        lineEdit_2 = new QLineEdit(Formcalc_advance);
        lineEdit_2->setObjectName(QStringLiteral("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(420, 110, 380, 21));
        lineEdit_2->setFont(font4);
        lineEdit_2->setStyleSheet(QLatin1String("color: #585858;\n"
"background:#e0e0e0;"));
        pushButton_7 = new QPushButton(Formcalc_advance);
        pushButton_7->setObjectName(QStringLiteral("pushButton_7"));
        pushButton_7->setGeometry(QRect(280, 140, 101, 31));
        QFont font5;
        font5.setPointSize(12);
        pushButton_7->setFont(font5);
        pushButton_7->setCursor(QCursor(Qt::PointingHandCursor));
        pushButton_7->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        pushButton_7->setFlat(true);
        pushButton_8 = new QPushButton(Formcalc_advance);
        pushButton_8->setObjectName(QStringLiteral("pushButton_8"));
        pushButton_8->setGeometry(QRect(700, 140, 101, 31));
        QFont font6;
        font6.setFamily(QStringLiteral("Segoe UI"));
        font6.setPointSize(12);
        pushButton_8->setFont(font6);
        pushButton_8->setCursor(QCursor(Qt::PointingHandCursor));
        pushButton_8->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        pushButton_8->setFlat(true);
        label_5 = new QLabel(Formcalc_advance);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(10, 170, 91, 31));
        label_5->setFont(font2);
        label_5->setStyleSheet(QStringLiteral("color:white;"));
        label_6 = new QLabel(Formcalc_advance);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(420, 160, 50, 51));
        label_6->setFont(font3);
        label_6->setStyleSheet(QStringLiteral("color:white;"));
        lineEdit_3 = new QLineEdit(Formcalc_advance);
        lineEdit_3->setObjectName(QStringLiteral("lineEdit_3"));
        lineEdit_3->setGeometry(QRect(10, 200, 371, 21));
        lineEdit_3->setFont(font4);
        lineEdit_3->setStyleSheet(QLatin1String("color: #585858;\n"
"background:#e0e0e0;"));
        lineEdit_3->setReadOnly(true);
        lineEdit_4 = new QLineEdit(Formcalc_advance);
        lineEdit_4->setObjectName(QStringLiteral("lineEdit_4"));
        lineEdit_4->setGeometry(QRect(420, 200, 380, 21));
        lineEdit_4->setFont(font4);
        lineEdit_4->setStyleSheet(QLatin1String("color: #585858;\n"
"background:#e0e0e0;"));
        lineEdit_4->setReadOnly(true);
        label_7 = new QLabel(Formcalc_advance);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setGeometry(QRect(10, 240, 361, 281));
        label_7->setStyleSheet(QStringLiteral("background-color:#ffffff;"));
        label_8 = new QLabel(Formcalc_advance);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setGeometry(QRect(430, 240, 370, 281));
        label_8->setStyleSheet(QStringLiteral("background-color:#ffffff;"));

        retranslateUi(Formcalc_advance);

        QMetaObject::connectSlotsByName(Formcalc_advance);
    } // setupUi

    void retranslateUi(QWidget *Formcalc_advance)
    {
        Formcalc_advance->setWindowTitle(QApplication::translate("Formcalc_advance", "FormCalc - Advance", 0));
        pushButton->setText(QApplication::translate("Formcalc_advance", "Save", 0));
        pushButton_2->setText(QApplication::translate("Formcalc_advance", "Reset", 0));
        graph_btn->setText(QApplication::translate("Formcalc_advance", "Graph", 0));
        advance_btn->setText(QApplication::translate("Formcalc_advance", "Advance", 0));
        scientific_btn->setText(QApplication::translate("Formcalc_advance", "Scientific", 0));
        basic_btn->setText(QApplication::translate("Formcalc_advance", "Basic", 0));
        comboBox->clear();
        comboBox->insertItems(0, QStringList()
         << QApplication::translate("Formcalc_advance", "History", 0)
        );
        label->setText(QApplication::translate("Formcalc_advance", "Derivative Calculator", 0));
        label_2->setText(QApplication::translate("Formcalc_advance", "Integral Calculator", 0));
        label_3->setText(QApplication::translate("Formcalc_advance", "y = f(x)", 0));
        label_4->setText(QApplication::translate("Formcalc_advance", "y = f(x)", 0));
        pushButton_7->setText(QApplication::translate("Formcalc_advance", "Calculate", 0));
        pushButton_8->setText(QApplication::translate("Formcalc_advance", "Calculate", 0));
        label_5->setText(QApplication::translate("Formcalc_advance", "dy / dx", 0));
        label_6->setText(QApplication::translate("Formcalc_advance", "\342\210\253ydx", 0));
        label_7->setText(QString());
        label_8->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class Formcalc_advance: public Ui_Formcalc_advance {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FORMCALC_ADVANCE_H

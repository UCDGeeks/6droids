/********************************************************************************
** Form generated from reading UI file 'formcalc_scientific.ui'
**
** Created by: Qt User Interface Compiler version 5.4.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FORMCALC_SCIENTIFIC_H
#define UI_FORMCALC_SCIENTIFIC_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_FormCalc_Scientific
{
public:
    QLineEdit *formular_txtline;
    QLineEdit *total_txtline;
    QLineEdit *prvtotal_txtline;
    QPushButton *graph_btn;
    QPushButton *advance_btn;
    QPushButton *scientific_btn;
    QPushButton *basic_btn;
    QPushButton *save_btn;
    QPushButton *reload_btn;
    QPushButton *mminus_btn;
    QPushButton *mplus_btn;
    QPushButton *ms_btn;
    QPushButton *mr_btn;
    QPushButton *mc_btn;
    QPushButton *del_btn;
    QPushButton *ce_btn;
    QPushButton *c_btn;
    QPushButton *plusormin_btn;
    QPushButton *root_btn;
    QPushButton *seven_btn;
    QPushButton *eight_btn;
    QPushButton *nine_btn;
    QPushButton *divide_btn;
    QPushButton *precentage_btn;
    QPushButton *four_btn;
    QPushButton *five_btn;
    QPushButton *six_btn;
    QPushButton *multiply_btn;
    QPushButton *reciprocal_btn;
    QPushButton *one_btn;
    QPushButton *two_btn;
    QPushButton *three_btn;
    QPushButton *min_btn;
    QPushButton *equal_btn;
    QPushButton *zero_btn;
    QPushButton *dot_btn;
    QPushButton *plus_btn;
    QComboBox *comboBox;
    QPushButton *del_btn_2;
    QPushButton *inverse_btn;
    QPushButton *ln_btn;
    QPushButton *openbrace_btn;
    QPushButton *closebrace_btn;
    QPushButton *int_btn;
    QPushButton *cosec_btn;
    QPushButton *sin_btn;
    QPushButton *square_btn;
    QPushButton *factotial_btn;
    QPushButton *decimeter_btn;
    QPushButton *sec_btn;
    QPushButton *cos_btn;
    QPushButton *xpowery_btn;
    QPushButton *nthrooth_btn;
    QPushButton *pi_btn;
    QPushButton *cot_btn;
    QPushButton *tan_btn;
    QPushButton *cube_btn;
    QPushButton *cuberoot_btn;
    QPushButton *pushButton_55;
    QPushButton *exponent_btn;
    QPushButton *mod_btn;
    QPushButton *log_btn;
    QPushButton *inverselog_btn;
    QRadioButton *radioButton;
    QRadioButton *radioButton_2;

    void setupUi(QWidget *FormCalc_Scientific)
    {
        if (FormCalc_Scientific->objectName().isEmpty())
            FormCalc_Scientific->setObjectName(QStringLiteral("FormCalc_Scientific"));
        FormCalc_Scientific->resize(810, 520);
        FormCalc_Scientific->setMinimumSize(QSize(810, 520));
        FormCalc_Scientific->setMaximumSize(QSize(810, 520));
        QFont font;
        font.setFamily(QStringLiteral("Segoe UI"));
        FormCalc_Scientific->setFont(font);
        FormCalc_Scientific->setCursor(QCursor(Qt::ArrowCursor));
        QIcon icon;
        icon.addFile(QStringLiteral(":/icon/window_icon_2.png"), QSize(), QIcon::Normal, QIcon::Off);
        FormCalc_Scientific->setWindowIcon(icon);
        FormCalc_Scientific->setAutoFillBackground(false);
        FormCalc_Scientific->setStyleSheet(QStringLiteral("background:#909090;"));
        formular_txtline = new QLineEdit(FormCalc_Scientific);
        formular_txtline->setObjectName(QStringLiteral("formular_txtline"));
        formular_txtline->setGeometry(QRect(0, 0, 811, 20));
        QFont font1;
        font1.setPointSize(10);
        formular_txtline->setFont(font1);
        formular_txtline->setStyleSheet(QLatin1String("color:#000000;\n"
"background:#e0e0e0;"));
        formular_txtline->setFrame(false);
        formular_txtline->setAlignment(Qt::AlignBottom|Qt::AlignRight|Qt::AlignTrailing);
        formular_txtline->setReadOnly(true);
        total_txtline = new QLineEdit(FormCalc_Scientific);
        total_txtline->setObjectName(QStringLiteral("total_txtline"));
        total_txtline->setGeometry(QRect(0, 20, 811, 41));
        QFont font2;
        font2.setFamily(QStringLiteral("Segoe UI"));
        font2.setPointSize(15);
        font2.setBold(true);
        font2.setWeight(75);
        total_txtline->setFont(font2);
        total_txtline->setStyleSheet(QLatin1String("color:#000000;\n"
"background:#e0e0e0;"));
        total_txtline->setFrame(false);
        total_txtline->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        prvtotal_txtline = new QLineEdit(FormCalc_Scientific);
        prvtotal_txtline->setObjectName(QStringLiteral("prvtotal_txtline"));
        prvtotal_txtline->setGeometry(QRect(0, 60, 811, 21));
        QFont font3;
        font3.setPointSize(10);
        font3.setBold(false);
        font3.setWeight(50);
        prvtotal_txtline->setFont(font3);
        prvtotal_txtline->setStyleSheet(QLatin1String("color:#000000;\n"
"background:#e0e0e0;"));
        prvtotal_txtline->setFrame(false);
        prvtotal_txtline->setAlignment(Qt::AlignRight|Qt::AlignTop|Qt::AlignTrailing);
        prvtotal_txtline->setReadOnly(true);
        graph_btn = new QPushButton(FormCalc_Scientific);
        graph_btn->setObjectName(QStringLiteral("graph_btn"));
        graph_btn->setGeometry(QRect(710, 80, 101, 51));
        QFont font4;
        font4.setFamily(QStringLiteral("Segoe UI"));
        font4.setPointSize(15);
        font4.setBold(false);
        font4.setWeight(50);
        graph_btn->setFont(font4);
        graph_btn->setCursor(QCursor(Qt::PointingHandCursor));
        graph_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;\n"
"\n"
"/*\n"
"	border-top-right-radius: 20px;\n"
"	border-bottom-right-radius: 20px;\n"
"*/"));
        graph_btn->setFlat(true);
        advance_btn = new QPushButton(FormCalc_Scientific);
        advance_btn->setObjectName(QStringLiteral("advance_btn"));
        advance_btn->setGeometry(QRect(610, 80, 101, 51));
        advance_btn->setFont(font4);
        advance_btn->setCursor(QCursor(Qt::PointingHandCursor));
        advance_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        advance_btn->setFlat(true);
        scientific_btn = new QPushButton(FormCalc_Scientific);
        scientific_btn->setObjectName(QStringLiteral("scientific_btn"));
        scientific_btn->setGeometry(QRect(510, 80, 101, 51));
        scientific_btn->setFont(font4);
        scientific_btn->setCursor(QCursor(Qt::PointingHandCursor));
        scientific_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #de8769;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        scientific_btn->setCheckable(true);
        scientific_btn->setChecked(true);
        scientific_btn->setDefault(true);
        scientific_btn->setFlat(true);
        basic_btn = new QPushButton(FormCalc_Scientific);
        basic_btn->setObjectName(QStringLiteral("basic_btn"));
        basic_btn->setGeometry(QRect(410, 80, 101, 51));
        basic_btn->setFont(font4);
        basic_btn->setCursor(QCursor(Qt::PointingHandCursor));
        basic_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;\n"
"\n"
"/*\n"
"	border-top-left-radius: 20px;\n"
"	border-bottom-left-radius: 20px;\n"
"*/"));
        basic_btn->setFlat(true);
        save_btn = new QPushButton(FormCalc_Scientific);
        save_btn->setObjectName(QStringLiteral("save_btn"));
        save_btn->setGeometry(QRect(80, 80, 101, 51));
        save_btn->setFont(font4);
        save_btn->setCursor(QCursor(Qt::PointingHandCursor));
        save_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;\n"
"\n"
"/*\n"
"	border-top-left-radius: 20px;\n"
"	border-bottom-left-radius: 20px;\n"
"*/"));
        save_btn->setFlat(true);
        reload_btn = new QPushButton(FormCalc_Scientific);
        reload_btn->setObjectName(QStringLiteral("reload_btn"));
        reload_btn->setGeometry(QRect(180, 80, 101, 51));
        reload_btn->setFont(font4);
        reload_btn->setCursor(QCursor(Qt::PointingHandCursor));
        reload_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;\n"
"\n"
"/*\n"
"	border-top-right-radius: 20px;\n"
"	border-bottom-right-radius: 20px;\n"
"*/"));
        reload_btn->setFlat(true);
        mminus_btn = new QPushButton(FormCalc_Scientific);
        mminus_btn->setObjectName(QStringLiteral("mminus_btn"));
        mminus_btn->setGeometry(QRect(730, 150, 81, 51));
        mminus_btn->setFont(font4);
        mminus_btn->setCursor(QCursor(Qt::PointingHandCursor));
        mminus_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        mminus_btn->setFlat(true);
        mplus_btn = new QPushButton(FormCalc_Scientific);
        mplus_btn->setObjectName(QStringLiteral("mplus_btn"));
        mplus_btn->setGeometry(QRect(650, 150, 81, 51));
        mplus_btn->setFont(font4);
        mplus_btn->setCursor(QCursor(Qt::PointingHandCursor));
        mplus_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        mplus_btn->setFlat(true);
        ms_btn = new QPushButton(FormCalc_Scientific);
        ms_btn->setObjectName(QStringLiteral("ms_btn"));
        ms_btn->setGeometry(QRect(570, 150, 81, 51));
        ms_btn->setFont(font4);
        ms_btn->setCursor(QCursor(Qt::PointingHandCursor));
        ms_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        ms_btn->setFlat(true);
        mr_btn = new QPushButton(FormCalc_Scientific);
        mr_btn->setObjectName(QStringLiteral("mr_btn"));
        mr_btn->setGeometry(QRect(490, 150, 81, 51));
        mr_btn->setFont(font4);
        mr_btn->setCursor(QCursor(Qt::PointingHandCursor));
        mr_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        mr_btn->setFlat(true);
        mc_btn = new QPushButton(FormCalc_Scientific);
        mc_btn->setObjectName(QStringLiteral("mc_btn"));
        mc_btn->setGeometry(QRect(410, 150, 81, 51));
        mc_btn->setFont(font4);
        mc_btn->setCursor(QCursor(Qt::PointingHandCursor));
        mc_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        mc_btn->setFlat(true);
        del_btn = new QPushButton(FormCalc_Scientific);
        del_btn->setObjectName(QStringLiteral("del_btn"));
        del_btn->setGeometry(QRect(410, 200, 81, 51));
        QFont font5;
        font5.setFamily(QStringLiteral("Segoe UI"));
        font5.setPointSize(25);
        font5.setBold(false);
        font5.setWeight(50);
        del_btn->setFont(font5);
        del_btn->setCursor(QCursor(Qt::PointingHandCursor));
        del_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        del_btn->setFlat(true);
        ce_btn = new QPushButton(FormCalc_Scientific);
        ce_btn->setObjectName(QStringLiteral("ce_btn"));
        ce_btn->setGeometry(QRect(490, 200, 81, 51));
        ce_btn->setFont(font4);
        ce_btn->setCursor(QCursor(Qt::PointingHandCursor));
        ce_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        ce_btn->setFlat(true);
        c_btn = new QPushButton(FormCalc_Scientific);
        c_btn->setObjectName(QStringLiteral("c_btn"));
        c_btn->setGeometry(QRect(570, 200, 81, 51));
        c_btn->setFont(font4);
        c_btn->setCursor(QCursor(Qt::PointingHandCursor));
        c_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        c_btn->setFlat(true);
        plusormin_btn = new QPushButton(FormCalc_Scientific);
        plusormin_btn->setObjectName(QStringLiteral("plusormin_btn"));
        plusormin_btn->setGeometry(QRect(650, 200, 81, 51));
        plusormin_btn->setFont(font4);
        plusormin_btn->setCursor(QCursor(Qt::PointingHandCursor));
        plusormin_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        plusormin_btn->setFlat(true);
        root_btn = new QPushButton(FormCalc_Scientific);
        root_btn->setObjectName(QStringLiteral("root_btn"));
        root_btn->setGeometry(QRect(730, 200, 81, 51));
        root_btn->setFont(font4);
        root_btn->setCursor(QCursor(Qt::PointingHandCursor));
        root_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        root_btn->setFlat(true);
        seven_btn = new QPushButton(FormCalc_Scientific);
        seven_btn->setObjectName(QStringLiteral("seven_btn"));
        seven_btn->setGeometry(QRect(410, 250, 81, 51));
        seven_btn->setFont(font2);
        seven_btn->setCursor(QCursor(Qt::PointingHandCursor));
        seven_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #cacaca;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        seven_btn->setFlat(true);
        eight_btn = new QPushButton(FormCalc_Scientific);
        eight_btn->setObjectName(QStringLiteral("eight_btn"));
        eight_btn->setGeometry(QRect(490, 250, 81, 51));
        eight_btn->setFont(font2);
        eight_btn->setCursor(QCursor(Qt::PointingHandCursor));
        eight_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #cacaca;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        eight_btn->setFlat(true);
        nine_btn = new QPushButton(FormCalc_Scientific);
        nine_btn->setObjectName(QStringLiteral("nine_btn"));
        nine_btn->setGeometry(QRect(570, 250, 81, 51));
        nine_btn->setFont(font2);
        nine_btn->setCursor(QCursor(Qt::PointingHandCursor));
        nine_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #cacaca;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        nine_btn->setFlat(true);
        divide_btn = new QPushButton(FormCalc_Scientific);
        divide_btn->setObjectName(QStringLiteral("divide_btn"));
        divide_btn->setGeometry(QRect(650, 250, 81, 51));
        divide_btn->setFont(font4);
        divide_btn->setCursor(QCursor(Qt::PointingHandCursor));
        divide_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #f4d16a;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        divide_btn->setFlat(true);
        precentage_btn = new QPushButton(FormCalc_Scientific);
        precentage_btn->setObjectName(QStringLiteral("precentage_btn"));
        precentage_btn->setGeometry(QRect(730, 250, 81, 51));
        precentage_btn->setFont(font4);
        precentage_btn->setCursor(QCursor(Qt::PointingHandCursor));
        precentage_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        precentage_btn->setFlat(true);
        four_btn = new QPushButton(FormCalc_Scientific);
        four_btn->setObjectName(QStringLiteral("four_btn"));
        four_btn->setGeometry(QRect(410, 300, 81, 51));
        four_btn->setFont(font2);
        four_btn->setCursor(QCursor(Qt::PointingHandCursor));
        four_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #cacaca;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        four_btn->setFlat(true);
        five_btn = new QPushButton(FormCalc_Scientific);
        five_btn->setObjectName(QStringLiteral("five_btn"));
        five_btn->setGeometry(QRect(490, 300, 81, 51));
        five_btn->setFont(font2);
        five_btn->setCursor(QCursor(Qt::PointingHandCursor));
        five_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #cacaca;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        five_btn->setFlat(true);
        six_btn = new QPushButton(FormCalc_Scientific);
        six_btn->setObjectName(QStringLiteral("six_btn"));
        six_btn->setGeometry(QRect(570, 300, 81, 51));
        six_btn->setFont(font2);
        six_btn->setCursor(QCursor(Qt::PointingHandCursor));
        six_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #cacaca;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        six_btn->setFlat(true);
        multiply_btn = new QPushButton(FormCalc_Scientific);
        multiply_btn->setObjectName(QStringLiteral("multiply_btn"));
        multiply_btn->setGeometry(QRect(650, 300, 81, 51));
        multiply_btn->setFont(font4);
        multiply_btn->setCursor(QCursor(Qt::PointingHandCursor));
        multiply_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #f4d16a;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        multiply_btn->setFlat(true);
        reciprocal_btn = new QPushButton(FormCalc_Scientific);
        reciprocal_btn->setObjectName(QStringLiteral("reciprocal_btn"));
        reciprocal_btn->setGeometry(QRect(730, 300, 81, 51));
        reciprocal_btn->setFont(font4);
        reciprocal_btn->setCursor(QCursor(Qt::PointingHandCursor));
        reciprocal_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        reciprocal_btn->setFlat(true);
        one_btn = new QPushButton(FormCalc_Scientific);
        one_btn->setObjectName(QStringLiteral("one_btn"));
        one_btn->setGeometry(QRect(410, 350, 81, 51));
        one_btn->setFont(font2);
        one_btn->setCursor(QCursor(Qt::PointingHandCursor));
        one_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #cacaca;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        one_btn->setFlat(true);
        two_btn = new QPushButton(FormCalc_Scientific);
        two_btn->setObjectName(QStringLiteral("two_btn"));
        two_btn->setGeometry(QRect(490, 350, 81, 51));
        two_btn->setFont(font2);
        two_btn->setCursor(QCursor(Qt::PointingHandCursor));
        two_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #cacaca;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        two_btn->setFlat(true);
        three_btn = new QPushButton(FormCalc_Scientific);
        three_btn->setObjectName(QStringLiteral("three_btn"));
        three_btn->setGeometry(QRect(570, 350, 81, 51));
        three_btn->setFont(font2);
        three_btn->setCursor(QCursor(Qt::PointingHandCursor));
        three_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #cacaca;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        three_btn->setFlat(true);
        min_btn = new QPushButton(FormCalc_Scientific);
        min_btn->setObjectName(QStringLiteral("min_btn"));
        min_btn->setGeometry(QRect(650, 350, 81, 51));
        min_btn->setFont(font5);
        min_btn->setCursor(QCursor(Qt::PointingHandCursor));
        min_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #f4d16a;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        min_btn->setFlat(true);
        equal_btn = new QPushButton(FormCalc_Scientific);
        equal_btn->setObjectName(QStringLiteral("equal_btn"));
        equal_btn->setGeometry(QRect(730, 350, 81, 101));
        equal_btn->setFont(font4);
        equal_btn->setCursor(QCursor(Qt::PointingHandCursor));
        equal_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #69c86f;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        equal_btn->setFlat(true);
        zero_btn = new QPushButton(FormCalc_Scientific);
        zero_btn->setObjectName(QStringLiteral("zero_btn"));
        zero_btn->setGeometry(QRect(410, 400, 161, 51));
        zero_btn->setFont(font2);
        zero_btn->setCursor(QCursor(Qt::PointingHandCursor));
        zero_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #cacaca;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        zero_btn->setFlat(true);
        dot_btn = new QPushButton(FormCalc_Scientific);
        dot_btn->setObjectName(QStringLiteral("dot_btn"));
        dot_btn->setGeometry(QRect(570, 400, 81, 51));
        dot_btn->setFont(font5);
        dot_btn->setCursor(QCursor(Qt::PointingHandCursor));
        dot_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #cacaca;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        dot_btn->setFlat(true);
        plus_btn = new QPushButton(FormCalc_Scientific);
        plus_btn->setObjectName(QStringLiteral("plus_btn"));
        plus_btn->setGeometry(QRect(650, 400, 81, 51));
        plus_btn->setFont(font4);
        plus_btn->setCursor(QCursor(Qt::PointingHandCursor));
        plus_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #f4d16a;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        plus_btn->setFlat(true);
        comboBox = new QComboBox(FormCalc_Scientific);
        comboBox->setObjectName(QStringLiteral("comboBox"));
        comboBox->setGeometry(QRect(410, 460, 401, 61));
        QFont font6;
        font6.setFamily(QStringLiteral("Segoe UI"));
        font6.setPointSize(20);
        font6.setBold(false);
        font6.setWeight(50);
        comboBox->setFont(font6);
        comboBox->setCursor(QCursor(Qt::PointingHandCursor));
        comboBox->setStyleSheet(QLatin1String("QComboBox{	\n"
"	outline:none;\n"
"	color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 0px;\n"
"	border-radius:15px;\n"
"	border-color:#909090;\n"
"}\n"
" QComboBox::down-arrow {\n"
"    border-image:url(C:/Users/Sahitha Nelanga/Desktop/FormCalc/Project/FormCalc/GitLab/FormCalc/arrow.png);\n"
"	position: center;\n"
"	width: 16;\n"
"	height: 16;\n"
"    }\n"
"\n"
"QComboBox::drop-down {\n"
"width: 16px;\n"
"border-top-right-radius: 3px;\n"
"border-bottom-right-radius: 3px;\n"
"}\n"
"\n"
"QComboBox::down-arrow:on {\n"
"  	border-image:url(C:/Users/Sahitha Nelanga/Desktop/FormCalc/Project/FormCalc/GitLab/FormCalc/arrowup.png);\n"
"	position: center;\n"
"	width: 16;\n"
"	height: 16\n"
" }"));
        del_btn_2 = new QPushButton(FormCalc_Scientific);
        del_btn_2->setObjectName(QStringLiteral("del_btn_2"));
        del_btn_2->setGeometry(QRect(0, 200, 81, 51));
        del_btn_2->setFont(font5);
        del_btn_2->setCursor(QCursor(Qt::PointingHandCursor));
        del_btn_2->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        del_btn_2->setFlat(true);
        inverse_btn = new QPushButton(FormCalc_Scientific);
        inverse_btn->setObjectName(QStringLiteral("inverse_btn"));
        inverse_btn->setGeometry(QRect(80, 200, 81, 51));
        QFont font7;
        font7.setFamily(QStringLiteral("Segoe UI"));
        font7.setPointSize(15);
        inverse_btn->setFont(font7);
        inverse_btn->setCursor(QCursor(Qt::PointingHandCursor));
        inverse_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        inverse_btn->setFlat(true);
        ln_btn = new QPushButton(FormCalc_Scientific);
        ln_btn->setObjectName(QStringLiteral("ln_btn"));
        ln_btn->setGeometry(QRect(160, 200, 81, 51));
        ln_btn->setFont(font7);
        ln_btn->setCursor(QCursor(Qt::PointingHandCursor));
        ln_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        ln_btn->setFlat(true);
        openbrace_btn = new QPushButton(FormCalc_Scientific);
        openbrace_btn->setObjectName(QStringLiteral("openbrace_btn"));
        openbrace_btn->setGeometry(QRect(240, 200, 81, 51));
        openbrace_btn->setFont(font7);
        openbrace_btn->setCursor(QCursor(Qt::PointingHandCursor));
        openbrace_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        openbrace_btn->setFlat(true);
        closebrace_btn = new QPushButton(FormCalc_Scientific);
        closebrace_btn->setObjectName(QStringLiteral("closebrace_btn"));
        closebrace_btn->setGeometry(QRect(320, 200, 81, 51));
        closebrace_btn->setFont(font7);
        closebrace_btn->setCursor(QCursor(Qt::PointingHandCursor));
        closebrace_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        closebrace_btn->setFlat(true);
        int_btn = new QPushButton(FormCalc_Scientific);
        int_btn->setObjectName(QStringLiteral("int_btn"));
        int_btn->setGeometry(QRect(0, 250, 81, 51));
        int_btn->setFont(font7);
        int_btn->setCursor(QCursor(Qt::PointingHandCursor));
        int_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        int_btn->setFlat(true);
        cosec_btn = new QPushButton(FormCalc_Scientific);
        cosec_btn->setObjectName(QStringLiteral("cosec_btn"));
        cosec_btn->setGeometry(QRect(80, 250, 81, 51));
        cosec_btn->setFont(font7);
        cosec_btn->setCursor(QCursor(Qt::PointingHandCursor));
        cosec_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        cosec_btn->setFlat(true);
        sin_btn = new QPushButton(FormCalc_Scientific);
        sin_btn->setObjectName(QStringLiteral("sin_btn"));
        sin_btn->setGeometry(QRect(160, 250, 81, 51));
        sin_btn->setFont(font7);
        sin_btn->setCursor(QCursor(Qt::PointingHandCursor));
        sin_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        sin_btn->setFlat(true);
        square_btn = new QPushButton(FormCalc_Scientific);
        square_btn->setObjectName(QStringLiteral("square_btn"));
        square_btn->setGeometry(QRect(240, 250, 81, 51));
        square_btn->setFont(font7);
        square_btn->setCursor(QCursor(Qt::PointingHandCursor));
        square_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        square_btn->setFlat(true);
        factotial_btn = new QPushButton(FormCalc_Scientific);
        factotial_btn->setObjectName(QStringLiteral("factotial_btn"));
        factotial_btn->setGeometry(QRect(320, 250, 81, 51));
        factotial_btn->setFont(font7);
        factotial_btn->setCursor(QCursor(Qt::PointingHandCursor));
        factotial_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        factotial_btn->setFlat(true);
        decimeter_btn = new QPushButton(FormCalc_Scientific);
        decimeter_btn->setObjectName(QStringLiteral("decimeter_btn"));
        decimeter_btn->setGeometry(QRect(0, 300, 81, 51));
        decimeter_btn->setFont(font7);
        decimeter_btn->setCursor(QCursor(Qt::PointingHandCursor));
        decimeter_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        decimeter_btn->setFlat(true);
        sec_btn = new QPushButton(FormCalc_Scientific);
        sec_btn->setObjectName(QStringLiteral("sec_btn"));
        sec_btn->setGeometry(QRect(80, 300, 81, 51));
        sec_btn->setFont(font7);
        sec_btn->setCursor(QCursor(Qt::PointingHandCursor));
        sec_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        sec_btn->setFlat(true);
        cos_btn = new QPushButton(FormCalc_Scientific);
        cos_btn->setObjectName(QStringLiteral("cos_btn"));
        cos_btn->setGeometry(QRect(160, 300, 81, 51));
        cos_btn->setFont(font7);
        cos_btn->setCursor(QCursor(Qt::PointingHandCursor));
        cos_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        cos_btn->setFlat(true);
        xpowery_btn = new QPushButton(FormCalc_Scientific);
        xpowery_btn->setObjectName(QStringLiteral("xpowery_btn"));
        xpowery_btn->setGeometry(QRect(240, 300, 81, 51));
        xpowery_btn->setFont(font7);
        xpowery_btn->setCursor(QCursor(Qt::PointingHandCursor));
        xpowery_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        xpowery_btn->setFlat(true);
        nthrooth_btn = new QPushButton(FormCalc_Scientific);
        nthrooth_btn->setObjectName(QStringLiteral("nthrooth_btn"));
        nthrooth_btn->setGeometry(QRect(320, 300, 81, 51));
        nthrooth_btn->setFont(font7);
        nthrooth_btn->setCursor(QCursor(Qt::PointingHandCursor));
        nthrooth_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        nthrooth_btn->setFlat(true);
        pi_btn = new QPushButton(FormCalc_Scientific);
        pi_btn->setObjectName(QStringLiteral("pi_btn"));
        pi_btn->setGeometry(QRect(0, 350, 81, 51));
        pi_btn->setFont(font7);
        pi_btn->setCursor(QCursor(Qt::PointingHandCursor));
        pi_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        pi_btn->setFlat(true);
        cot_btn = new QPushButton(FormCalc_Scientific);
        cot_btn->setObjectName(QStringLiteral("cot_btn"));
        cot_btn->setGeometry(QRect(80, 350, 81, 51));
        cot_btn->setFont(font7);
        cot_btn->setCursor(QCursor(Qt::PointingHandCursor));
        cot_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        cot_btn->setFlat(true);
        tan_btn = new QPushButton(FormCalc_Scientific);
        tan_btn->setObjectName(QStringLiteral("tan_btn"));
        tan_btn->setGeometry(QRect(160, 350, 81, 51));
        tan_btn->setFont(font7);
        tan_btn->setCursor(QCursor(Qt::PointingHandCursor));
        tan_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        tan_btn->setFlat(true);
        cube_btn = new QPushButton(FormCalc_Scientific);
        cube_btn->setObjectName(QStringLiteral("cube_btn"));
        cube_btn->setGeometry(QRect(240, 350, 81, 51));
        cube_btn->setFont(font7);
        cube_btn->setCursor(QCursor(Qt::PointingHandCursor));
        cube_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        cube_btn->setFlat(true);
        cuberoot_btn = new QPushButton(FormCalc_Scientific);
        cuberoot_btn->setObjectName(QStringLiteral("cuberoot_btn"));
        cuberoot_btn->setGeometry(QRect(320, 350, 81, 51));
        cuberoot_btn->setFont(font7);
        cuberoot_btn->setCursor(QCursor(Qt::PointingHandCursor));
        cuberoot_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        cuberoot_btn->setFlat(true);
        pushButton_55 = new QPushButton(FormCalc_Scientific);
        pushButton_55->setObjectName(QStringLiteral("pushButton_55"));
        pushButton_55->setGeometry(QRect(0, 400, 81, 51));
        pushButton_55->setFont(font7);
        pushButton_55->setCursor(QCursor(Qt::PointingHandCursor));
        pushButton_55->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        pushButton_55->setFlat(true);
        exponent_btn = new QPushButton(FormCalc_Scientific);
        exponent_btn->setObjectName(QStringLiteral("exponent_btn"));
        exponent_btn->setGeometry(QRect(80, 400, 81, 51));
        exponent_btn->setFont(font7);
        exponent_btn->setCursor(QCursor(Qt::PointingHandCursor));
        exponent_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        exponent_btn->setFlat(true);
        mod_btn = new QPushButton(FormCalc_Scientific);
        mod_btn->setObjectName(QStringLiteral("mod_btn"));
        mod_btn->setGeometry(QRect(160, 400, 81, 51));
        mod_btn->setFont(font7);
        mod_btn->setCursor(QCursor(Qt::PointingHandCursor));
        mod_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        mod_btn->setFlat(true);
        log_btn = new QPushButton(FormCalc_Scientific);
        log_btn->setObjectName(QStringLiteral("log_btn"));
        log_btn->setGeometry(QRect(240, 400, 81, 51));
        log_btn->setFont(font7);
        log_btn->setCursor(QCursor(Qt::PointingHandCursor));
        log_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        log_btn->setFlat(true);
        inverselog_btn = new QPushButton(FormCalc_Scientific);
        inverselog_btn->setObjectName(QStringLiteral("inverselog_btn"));
        inverselog_btn->setGeometry(QRect(320, 400, 81, 51));
        inverselog_btn->setFont(font7);
        inverselog_btn->setCursor(QCursor(Qt::PointingHandCursor));
        inverselog_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        inverselog_btn->setFlat(true);
        radioButton = new QRadioButton(FormCalc_Scientific);
        radioButton->setObjectName(QStringLiteral("radioButton"));
        radioButton->setGeometry(QRect(90, 170, 82, 21));
        QFont font8;
        font8.setFamily(QStringLiteral("Segoe UI"));
        font8.setPointSize(12);
        font8.setBold(false);
        font8.setWeight(50);
        radioButton->setFont(font8);
        radioButton->setCursor(QCursor(Qt::PointingHandCursor));
        radioButton->setStyleSheet(QStringLiteral("color:white;"));
        radioButton->setChecked(true);
        radioButton_2 = new QRadioButton(FormCalc_Scientific);
        radioButton_2->setObjectName(QStringLiteral("radioButton_2"));
        radioButton_2->setGeometry(QRect(190, 170, 82, 21));
        radioButton_2->setFont(font8);
        radioButton_2->setCursor(QCursor(Qt::PointingHandCursor));
        radioButton_2->setStyleSheet(QStringLiteral("color:white;"));

        retranslateUi(FormCalc_Scientific);

        QMetaObject::connectSlotsByName(FormCalc_Scientific);
    } // setupUi

    void retranslateUi(QWidget *FormCalc_Scientific)
    {
        FormCalc_Scientific->setWindowTitle(QApplication::translate("FormCalc_Scientific", "FormCalc - Scientific", 0));
        graph_btn->setText(QApplication::translate("FormCalc_Scientific", "Graph", 0));
        advance_btn->setText(QApplication::translate("FormCalc_Scientific", "Advance", 0));
        scientific_btn->setText(QApplication::translate("FormCalc_Scientific", "Scientific", 0));
        basic_btn->setText(QApplication::translate("FormCalc_Scientific", "Basic", 0));
        save_btn->setText(QApplication::translate("FormCalc_Scientific", "Save", 0));
        reload_btn->setText(QApplication::translate("FormCalc_Scientific", "Reload", 0));
        mminus_btn->setText(QApplication::translate("FormCalc_Scientific", "M-", 0));
        mplus_btn->setText(QApplication::translate("FormCalc_Scientific", "M+", 0));
        ms_btn->setText(QApplication::translate("FormCalc_Scientific", "MS", 0));
        mr_btn->setText(QApplication::translate("FormCalc_Scientific", "MR", 0));
        mc_btn->setText(QApplication::translate("FormCalc_Scientific", "MC", 0));
        del_btn->setText(QApplication::translate("FormCalc_Scientific", "\342\206\220", 0));
        ce_btn->setText(QApplication::translate("FormCalc_Scientific", "CE", 0));
        c_btn->setText(QApplication::translate("FormCalc_Scientific", "C", 0));
        plusormin_btn->setText(QApplication::translate("FormCalc_Scientific", "\302\261", 0));
        root_btn->setText(QApplication::translate("FormCalc_Scientific", "\342\210\232", 0));
        seven_btn->setText(QApplication::translate("FormCalc_Scientific", "7", 0));
        eight_btn->setText(QApplication::translate("FormCalc_Scientific", "8", 0));
        nine_btn->setText(QApplication::translate("FormCalc_Scientific", "9", 0));
        divide_btn->setText(QApplication::translate("FormCalc_Scientific", "\303\267", 0));
        precentage_btn->setText(QApplication::translate("FormCalc_Scientific", "%", 0));
        four_btn->setText(QApplication::translate("FormCalc_Scientific", "4", 0));
        five_btn->setText(QApplication::translate("FormCalc_Scientific", "5", 0));
        six_btn->setText(QApplication::translate("FormCalc_Scientific", "6", 0));
        multiply_btn->setText(QApplication::translate("FormCalc_Scientific", "x", 0));
        reciprocal_btn->setText(QApplication::translate("FormCalc_Scientific", "1/x", 0));
        one_btn->setText(QApplication::translate("FormCalc_Scientific", "1", 0));
        two_btn->setText(QApplication::translate("FormCalc_Scientific", "2", 0));
        three_btn->setText(QApplication::translate("FormCalc_Scientific", "3", 0));
        min_btn->setText(QApplication::translate("FormCalc_Scientific", "-", 0));
        equal_btn->setText(QApplication::translate("FormCalc_Scientific", "=", 0));
        zero_btn->setText(QApplication::translate("FormCalc_Scientific", "0", 0));
        dot_btn->setText(QApplication::translate("FormCalc_Scientific", ".", 0));
        plus_btn->setText(QApplication::translate("FormCalc_Scientific", "+", 0));
        comboBox->clear();
        comboBox->insertItems(0, QStringList()
         << QApplication::translate("FormCalc_Scientific", "History", 0)
        );
        del_btn_2->setText(QApplication::translate("FormCalc_Scientific", "\342\206\220", 0));
        inverse_btn->setText(QApplication::translate("FormCalc_Scientific", "Inv", 0));
        ln_btn->setText(QApplication::translate("FormCalc_Scientific", "ln", 0));
        openbrace_btn->setText(QApplication::translate("FormCalc_Scientific", "(", 0));
        closebrace_btn->setText(QApplication::translate("FormCalc_Scientific", ")", 0));
        int_btn->setText(QApplication::translate("FormCalc_Scientific", "Int", 0));
        cosec_btn->setText(QApplication::translate("FormCalc_Scientific", "cosec", 0));
        sin_btn->setText(QApplication::translate("FormCalc_Scientific", "sin", 0));
        square_btn->setText(QApplication::translate("FormCalc_Scientific", "X\302\262", 0));
        factotial_btn->setText(QApplication::translate("FormCalc_Scientific", "n!", 0));
        decimeter_btn->setText(QApplication::translate("FormCalc_Scientific", "dms", 0));
        sec_btn->setText(QApplication::translate("FormCalc_Scientific", "sec", 0));
        cos_btn->setText(QApplication::translate("FormCalc_Scientific", "cos", 0));
        xpowery_btn->setText(QApplication::translate("FormCalc_Scientific", "X\312\270", 0));
        nthrooth_btn->setText(QApplication::translate("FormCalc_Scientific", "\312\270\342\210\232X", 0));
        pi_btn->setText(QApplication::translate("FormCalc_Scientific", "\317\200", 0));
        cot_btn->setText(QApplication::translate("FormCalc_Scientific", "cot", 0));
        tan_btn->setText(QApplication::translate("FormCalc_Scientific", "tan", 0));
        cube_btn->setText(QApplication::translate("FormCalc_Scientific", "X\302\263", 0));
        cuberoot_btn->setText(QApplication::translate("FormCalc_Scientific", "\302\263\342\210\232X", 0));
        pushButton_55->setText(QApplication::translate("FormCalc_Scientific", "F-E", 0));
        exponent_btn->setText(QApplication::translate("FormCalc_Scientific", "Exp", 0));
        mod_btn->setText(QApplication::translate("FormCalc_Scientific", "Mod", 0));
        log_btn->setText(QApplication::translate("FormCalc_Scientific", "log", 0));
        inverselog_btn->setText(QApplication::translate("FormCalc_Scientific", "10\313\243", 0));
        radioButton->setText(QApplication::translate("FormCalc_Scientific", "Degrees", 0));
        radioButton_2->setText(QApplication::translate("FormCalc_Scientific", "Radians", 0));
    } // retranslateUi

};

namespace Ui {
    class FormCalc_Scientific: public Ui_FormCalc_Scientific {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FORMCALC_SCIENTIFIC_H

/********************************************************************************
** Form generated from reading UI file 'formcalc_graph.ui'
**
** Created by: Qt User Interface Compiler version 5.4.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FORMCALC_GRAPH_H
#define UI_FORMCALC_GRAPH_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_FormCalc_Graph
{
public:
    QPushButton *save_btn;
    QPushButton *reload_btn;
    QPushButton *basic_btn;
    QPushButton *scientific_btn;
    QPushButton *graph_btn;
    QPushButton *advance_btn;
    QLabel *label;
    QLineEdit *lineEdit;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *label_6;
    QLineEdit *lineEdit_2;
    QPushButton *pushButton_5;

    void setupUi(QWidget *FormCalc_Graph)
    {
        if (FormCalc_Graph->objectName().isEmpty())
            FormCalc_Graph->setObjectName(QStringLiteral("FormCalc_Graph"));
        FormCalc_Graph->resize(810, 600);
        FormCalc_Graph->setMinimumSize(QSize(810, 600));
        FormCalc_Graph->setMaximumSize(QSize(810, 600));
        QIcon icon;
        icon.addFile(QStringLiteral(":/icon/window_icon_2.png"), QSize(), QIcon::Normal, QIcon::Off);
        FormCalc_Graph->setWindowIcon(icon);
        FormCalc_Graph->setStyleSheet(QStringLiteral("background:#909090;"));
        save_btn = new QPushButton(FormCalc_Graph);
        save_btn->setObjectName(QStringLiteral("save_btn"));
        save_btn->setGeometry(QRect(41, 0, 101, 51));
        QFont font;
        font.setFamily(QStringLiteral("Segoe UI"));
        font.setPointSize(15);
        font.setBold(false);
        font.setWeight(50);
        save_btn->setFont(font);
        save_btn->setCursor(QCursor(Qt::PointingHandCursor));
        save_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        reload_btn = new QPushButton(FormCalc_Graph);
        reload_btn->setObjectName(QStringLiteral("reload_btn"));
        reload_btn->setGeometry(QRect(140, 0, 101, 51));
        reload_btn->setFont(font);
        reload_btn->setCursor(QCursor(Qt::PointingHandCursor));
        reload_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        basic_btn = new QPushButton(FormCalc_Graph);
        basic_btn->setObjectName(QStringLiteral("basic_btn"));
        basic_btn->setGeometry(QRect(410, 0, 101, 51));
        basic_btn->setFont(font);
        basic_btn->setCursor(QCursor(Qt::PointingHandCursor));
        basic_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        scientific_btn = new QPushButton(FormCalc_Graph);
        scientific_btn->setObjectName(QStringLiteral("scientific_btn"));
        scientific_btn->setGeometry(QRect(510, 0, 101, 51));
        scientific_btn->setFont(font);
        scientific_btn->setCursor(QCursor(Qt::PointingHandCursor));
        scientific_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        graph_btn = new QPushButton(FormCalc_Graph);
        graph_btn->setObjectName(QStringLiteral("graph_btn"));
        graph_btn->setGeometry(QRect(710, 0, 101, 51));
        graph_btn->setFont(font);
        graph_btn->setCursor(QCursor(Qt::PointingHandCursor));
        graph_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #d08a71;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        advance_btn = new QPushButton(FormCalc_Graph);
        advance_btn->setObjectName(QStringLiteral("advance_btn"));
        advance_btn->setGeometry(QRect(610, 0, 101, 51));
        advance_btn->setFont(font);
        advance_btn->setCursor(QCursor(Qt::PointingHandCursor));
        advance_btn->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));
        label = new QLabel(FormCalc_Graph);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(20, 110, 161, 31));
        QFont font1;
        font1.setFamily(QStringLiteral("Segoe UI"));
        font1.setPointSize(12);
        font1.setBold(true);
        font1.setWeight(75);
        label->setFont(font1);
        label->setStyleSheet(QStringLiteral("color:white;"));
        lineEdit = new QLineEdit(FormCalc_Graph);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));
        lineEdit->setGeometry(QRect(20, 140, 331, 21));
        QFont font2;
        font2.setFamily(QStringLiteral("Segoe UI"));
        lineEdit->setFont(font2);
        lineEdit->setStyleSheet(QLatin1String("color: #585858;\n"
"background:#e0e0e0;"));
        label_2 = new QLabel(FormCalc_Graph);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(590, 60, 201, 261));
        label_2->setStyleSheet(QStringLiteral("background-color:#ffffff;"));
        label_2->setFrameShape(QFrame::WinPanel);
        label_3 = new QLabel(FormCalc_Graph);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(380, 60, 211, 261));
        label_3->setStyleSheet(QStringLiteral("background-color:#ffffff;"));
        label_3->setFrameShape(QFrame::WinPanel);
        label_3->setMidLineWidth(1);
        label_4 = new QLabel(FormCalc_Graph);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(380, 320, 211, 261));
        label_4->setStyleSheet(QStringLiteral("background-color:#ffffff;"));
        label_4->setFrameShape(QFrame::WinPanel);
        label_4->setMidLineWidth(1);
        label_5 = new QLabel(FormCalc_Graph);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(590, 320, 201, 261));
        label_5->setStyleSheet(QStringLiteral("background-color:#ffffff;"));
        label_5->setFrameShape(QFrame::WinPanel);
        label_6 = new QLabel(FormCalc_Graph);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(20, 180, 161, 31));
        label_6->setFont(font1);
        label_6->setStyleSheet(QStringLiteral("color:white;"));
        lineEdit_2 = new QLineEdit(FormCalc_Graph);
        lineEdit_2->setObjectName(QStringLiteral("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(20, 210, 331, 21));
        lineEdit_2->setFont(font2);
        lineEdit_2->setStyleSheet(QLatin1String("color: #585858;\n"
"background:#e0e0e0;"));
        pushButton_5 = new QPushButton(FormCalc_Graph);
        pushButton_5->setObjectName(QStringLiteral("pushButton_5"));
        pushButton_5->setGeometry(QRect(110, 550, 101, 31));
        QFont font3;
        font3.setPointSize(12);
        pushButton_5->setFont(font3);
        pushButton_5->setCursor(QCursor(Qt::PointingHandCursor));
        pushButton_5->setStyleSheet(QLatin1String("color:white;\n"
"	background-color: #5a5959;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color:#909090;"));

        retranslateUi(FormCalc_Graph);

        QMetaObject::connectSlotsByName(FormCalc_Graph);
    } // setupUi

    void retranslateUi(QWidget *FormCalc_Graph)
    {
        FormCalc_Graph->setWindowTitle(QApplication::translate("FormCalc_Graph", "FormCalc - Graph", 0));
        save_btn->setText(QApplication::translate("FormCalc_Graph", "Save", 0));
        reload_btn->setText(QApplication::translate("FormCalc_Graph", "Reload", 0));
        basic_btn->setText(QApplication::translate("FormCalc_Graph", "Basic", 0));
        scientific_btn->setText(QApplication::translate("FormCalc_Graph", "Scientific", 0));
        graph_btn->setText(QApplication::translate("FormCalc_Graph", "Graph", 0));
        advance_btn->setText(QApplication::translate("FormCalc_Graph", "Advance", 0));
        label->setText(QApplication::translate("FormCalc_Graph", "f(x)", 0));
        label_2->setText(QString());
        label_3->setText(QString());
        label_4->setText(QString());
        label_5->setText(QString());
        label_6->setText(QApplication::translate("FormCalc_Graph", "g(x)", 0));
        pushButton_5->setText(QApplication::translate("FormCalc_Graph", "Add Line", 0));
    } // retranslateUi

};

namespace Ui {
    class FormCalc_Graph: public Ui_FormCalc_Graph {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FORMCALC_GRAPH_H

FormCalc Scientific & Integral Calculator
=========================================

**“FormCalc”** is a software calculator which is implemented as a Computer Program, not as a physical hardware device. 
**“FormCalc”** is different from the standard calculators. It is different because, user doesn’t have to enter keys or commands each and every step in order to get the end result. 
It’s a symbolic calculator allows user to enter the formula in symbolic forms to generate/obtain the end result at once. 
**“FormCalc”** in other words, reflects a combination of a standard calculator app and a mathematical software package in your desktop. 

**Special features**
-----------------

-Differentiation calculator

-Integral calculator 

-Graphs creator 

-Save and Reload formulas / equations 

-Quick access history recorder


**Team Members**
-----------------

-**Tharkana Kodagoda** (*Team Leader / Developer*)

-**Srimal Priyanga** (*Developer*)

-**Sahitha Nelanga De Silva** (*UI Designer / Developer*)

-**Kavindu Narathota** (*UI Designer / Developer*)

-**Dilina Namal Weerasinghe** (*QA / Reporting*)

-**Poorni Yasodara** (*QA / Reporting*)
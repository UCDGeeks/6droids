/**
*
*Team ~6Droids~
*
*/

#include "formcalc_scientific.h"
#include "ui_formcalc_scientific.h"
#include <qstring.h>
//#include <QKeyEvent>
#include <QMessageBox>

bool oparatorclick = false , numberClick = false;

bool totalSelected = false, valueSelected = false;


FormCalc_Scientific::FormCalc_Scientific(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::FormCalc_Scientific)
{
    ui->setupUi(this);
    ui->total_txtline->installEventFilter(this);
    ui->values_txtline->installEventFilter(this);
}


bool FormCalc_Scientific::eventFilter(QObject *obj, QEvent *event)
{
    if (event->type() == QEvent::FocusOut)
    {
        if (obj == ui->total_txtline){
            totalSelected = true;
            valueSelected = false;
        }

        if (obj == ui->values_txtline){
            totalSelected = false;
            valueSelected = true;
        }


        //if (obj == ui->lineEdit_3)
          // QMessageBox::information(this, "", "line3");

    }

    return false;
}


FormCalc_Scientific::~FormCalc_Scientific()
{
    delete ui;
}

void FormCalc_Scientific::on_graph_btn_clicked()
{
    dependencies d;
    d.openGraph();
    //this->close();
}

/**
 * @brief FormCalc_Scientific::appenedin
 *  -appending is the function which all the numpad buttons calls when they were clicked.
 *
 * @param totalline
 *  -totalline is which types on the total_txtline.
 */
void FormCalc_Scientific::appenedin(QString totalline)
{

    numberClick = true;

    if(oparatorclick){
         QString input = ui->total_txtline->text();
         ui->total_txtline->setText(totalline);
         oparatorclick = false;
     }
     else{
         QString input = ui->total_txtline->text();
         ui->total_txtline->setText(input+totalline);
     }

}

/**
 * @brief FormCalc_Scientific::notempty_appenedin
 *
 * @param op
 */
void FormCalc_Scientific::notempty_appenedin(QString op)
{

    if(numberClick){
        numberClick = false;
        if(ui->total_txtline->text().isEmpty()){
            ui->total_txtline->setText("0"+op);
            //ui->formular_txtline->setText("0"+op);
        }

        /*else if(ui->formular_txtline->text().isEmpty()){

            //QString previnput = ui->formular_txtline->text();
            QString input = ui->total_txtline->text();
            ui->formular_txtline->setText(input+op);

        }*/

        //else{
            //QString previnput = ui->formular_txtline->text();
            //QString input = ui->total_txtline->text();
            //ui->formular_txtline->setText(previnput+input+op);
       // }
    }
//    else {

      //  QString previnput = ui->formular_txtline->text();
      //  previnput.remove(previnput.size()-1, previnput.size());

      //  ui->formular_txtline->setText(previnput+op);

    //}



       // QString input = ui->total_txtline->text();
       // QString inputformular = ui->formular_txtline->text();
       // ui->formular_txtline->setText(input+op);

}



//Print numpad numbers to textline
void FormCalc_Scientific::on_zero_btn_clicked()
{
    /*if(ui->total_txtline->text()==("0")){

    }
    else{
    appenedin("0");
    }*/
}

void FormCalc_Scientific::on_one_btn_clicked()
{
    appenedin("1");
}

void FormCalc_Scientific::on_two_btn_clicked()
{
    appenedin("2");
}

void FormCalc_Scientific::on_three_btn_clicked()
{
    appenedin("3");
}

void FormCalc_Scientific::on_four_btn_clicked()
{
    appenedin("4");
}

void FormCalc_Scientific::on_five_btn_clicked()
{
    appenedin("5");
}

void FormCalc_Scientific::on_six_btn_clicked()
{
    appenedin("6");
}

void FormCalc_Scientific::on_seven_btn_clicked()
{
    appenedin("7");
}

void FormCalc_Scientific::on_eight_btn_clicked()
{
    appenedin("8");
}

void FormCalc_Scientific::on_nine_btn_clicked()
{
    appenedin("9");
}

void FormCalc_Scientific::on_dot_btn_clicked()
{
    /*if(ui->total_txtline->text().isEmpty()){

    }
    else if(ui->total_txtline->text().contains(".")){

    }
    else{
    appenedin(".");
    }*/
}

void FormCalc_Scientific::on_plus_btn_clicked()
{

    oparatorclick = true;
    notempty_appenedin("+");
    //appenedin("+");
}

void FormCalc_Scientific::on_min_btn_clicked()
{
    oparatorclick = true;
    notempty_appenedin("-");
}

void FormCalc_Scientific::on_multiply_btn_clicked()
{
    oparatorclick = true;
    notempty_appenedin("*");
}

void FormCalc_Scientific::on_divide_btn_clicked()
{
    oparatorclick = true;
    notempty_appenedin("/");
}
//-END-Print numpad numbers to textline

void FormCalc_Scientific::on_c_btn_clicked()
{
    /*ui->formular_txtline->setText("");
    ui->total_txtline->setText("");*/
}

void FormCalc_Scientific::on_ce_btn_clicked()
{
    /*ui->total_txtline->setText("");*/
}

void FormCalc_Scientific::on_plusormin_btn_clicked()
{
    /*QString input = ui->total_txtline->text();
    if(ui->total_txtline->text().contains("-")){
        input.remove(0,1);
        ui->total_txtline->setText(input);
    }
    else{
        ui->total_txtline->setText("-"+input);
    }*/
}

void FormCalc_Scientific::on_del_btn_clicked()
{
    /*QString input = ui->total_txtline->text();
    input = input.remove( (input.size()-1) , (input.size()) );
    ui->total_txtline->setText(input);*/
}

void FormCalc_Scientific::on_openbrace_btn_clicked(){
    appenedin("(");
}

void FormCalc_Scientific::on_closebrace_btn_clicked(){
    appenedin(")");
}


void FormCalc_Scientific::on_cosec_btn_clicked()
{
    appenedin("cosec(");
}

void FormCalc_Scientific::on_sin_btn_clicked()
{
    appenedin("sin(");
}

void FormCalc_Scientific::on_sec_btn_clicked()
{
    appenedin("sec(");
}

void FormCalc_Scientific::on_cos_btn_clicked()
{
    appenedin("cos(");
}

void FormCalc_Scientific::on_cot_btn_clicked()
{
    appenedin("cot(");
}

void FormCalc_Scientific::on_tan_btn_clicked()
{
    appenedin("tan(");
}

void FormCalc_Scientific::on_pi_btn_clicked()
{
    appenedin("3.1415926535897932384626433832795");
}

void FormCalc_Scientific::on_square_btn_clicked()
{
    if(ui->total_txtline->text().isEmpty()){

      }
    else {
        appenedin("^2");
    }

}



void FormCalc_Scientific::on_x_btn_clicked()
{
    if(totalSelected){
        QString input = ui->total_txtline->text();
        ui->total_txtline->setText(input+"x");

    }
    else if(valueSelected){
        QString input = ui->values_txtline->text();
        ui->values_txtline->setText(input+"x");

    }

}

void FormCalc_Scientific::on_y_btn_clicked()
{
    if(totalSelected){
        QString input = ui->total_txtline->text();
        ui->total_txtline->setText(input+"y");

    }
    else if(valueSelected){
        QString input = ui->values_txtline->text();
        ui->values_txtline->setText(input+"y");

    }
}

void FormCalc_Scientific::on_z_btn_clicked()
{
    if(totalSelected){
        QString input = ui->total_txtline->text();
        ui->total_txtline->setText(input+"z");

    }
    else if(valueSelected){
        QString input = ui->values_txtline->text();
        ui->values_txtline->setText(input+"z");

    }
}

void FormCalc_Scientific::on_xpowery_btn_clicked()
{
    appenedin("^");
}

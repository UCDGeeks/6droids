/**
*
*Team ~6Droids~
*
*/

#ifndef FORMCALC_SCIENTIFIC_H
#define FORMCALC_SCIENTIFIC_H


//#include <QMainWindow>
#include <QWidget>
#include "dependencies.h"




namespace Ui {
class FormCalc_Scientific;
}

class FormCalc_Scientific : public QWidget
{
    Q_OBJECT

public:
    explicit FormCalc_Scientific(QWidget *parent = 0);
    ~FormCalc_Scientific();

    bool eventFilter(QObject *obj, QEvent *event);


private:

   Ui::FormCalc_Scientific *ui;
   void appenedin(QString totalline);
   void notempty_appenedin(QString formularline);
   //void focusOutEvent(QFocusEvent *e);



private slots:
   //window switching
   void on_graph_btn_clicked();
   //-END-window switching

   //numpad slots
   void on_zero_btn_clicked();
   void on_one_btn_clicked();
   void on_two_btn_clicked();
   void on_three_btn_clicked();
   void on_four_btn_clicked();
   void on_five_btn_clicked();
   void on_six_btn_clicked();
   void on_seven_btn_clicked();
   void on_eight_btn_clicked();
   void on_nine_btn_clicked();
   void on_dot_btn_clicked();
   void on_plus_btn_clicked();
   void on_min_btn_clicked();
   void on_multiply_btn_clicked();
   void on_divide_btn_clicked();
   //-END-numpad slots

   void on_c_btn_clicked();
   void on_ce_btn_clicked();
   void on_plusormin_btn_clicked();
   void on_del_btn_clicked();

   void on_openbrace_btn_clicked();
   void on_closebrace_btn_clicked();
   void on_cosec_btn_clicked();
   void on_sin_btn_clicked();
   void on_sec_btn_clicked();
   void on_cos_btn_clicked();
   void on_cot_btn_clicked();
   void on_tan_btn_clicked();
   void on_pi_btn_clicked();
   void on_square_btn_clicked();
   void on_x_btn_clicked();
   void on_y_btn_clicked();
   void on_z_btn_clicked();
   void on_xpowery_btn_clicked();
};

#endif // FORMCALC_SCIENTIFIC_H

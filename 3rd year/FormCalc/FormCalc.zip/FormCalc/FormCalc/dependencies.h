/**
*
*Team ~6Droids~
*
*/

#ifndef DEPENDENCIES_H
#define DEPENDENCIES_H

#include "formcalc_scientific.h"
#include "formcalc_graph.h"
#include "qcustomplot.h"

class dependencies
{
public:
    dependencies();
    ~dependencies();

    void openScientific();
    void openGraph();

//private:


};

#endif // DEPENDENCIES_H

/**
*
*Team ~6Droids~
*
*/

#include "dependencies.h"

dependencies::dependencies()
{

}

dependencies::~dependencies()
{

}

void dependencies::openScientific(){
    FormCalc_Scientific *SWindow = new FormCalc_Scientific();
    SWindow->show();

}

void dependencies::openGraph(){
    FormCalc_Graph *AWindow = new FormCalc_Graph();
    AWindow->show();
}

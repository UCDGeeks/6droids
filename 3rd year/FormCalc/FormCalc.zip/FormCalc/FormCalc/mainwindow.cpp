/**
*
*Team ~6Droids~
*
*/

#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <qstring.h>

bool oparatorclick = false, numberClick = false;


MainWindow::MainWindow(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    //connect(ui->scientific_btn, SIGNAL(clicked()), this, SLOT(MainWindow::on_scientific_btn_clicked()));
    //connect(ui->advance_btn, SIGNAL(clicked()), this, SLOT(MainWindow::on_advance_btn_clicked()));
    //connect(ui->zero_btn, SIGNAL(clicked()), this, SLOT(MainWindow::on_advance_btn_clicked()));
}

MainWindow::~MainWindow()
{
    delete ui;

}

void MainWindow::on_scientific_btn_clicked()
{

    dependencies d;
    d.openScientific();
    this->close();

       /* scientific = new FormCalc_Scientific();
        scientific->show(); */

}

void MainWindow::on_graph_btn_clicked(){

      /*  advance = new Formcalc_advance();
        advance->show();  */
        dependencies d;
        d.openGraph();
        this->close();

}



/**
 * @brief MainWindow::appenedin
 *  -appending is the function which all the numpad buttons calls when they were clicked.
 *
 * @param totalline
 *  -totalline is which types on the total_txtline.
 */
void MainWindow::appenedin(QString totalline)
{
    //QString input = ui->formular_txtline->text();
    //ui->formular_txtline->setText(input+formular);

   numberClick = true;

   if(oparatorclick){
        //QString input = ui->total_txtline->text();
        ui->total_txtline->setText(totalline);
        oparatorclick = false;
    }
    else{
        QString input = ui->total_txtline->text();
        ui->total_txtline->setText(input+totalline);
    }

}

/**
 * @brief MainWindow::notempty_appenedin
 *
 * @param op
 */
void MainWindow::notempty_appenedin(QString op)
{

    if(numberClick){
        numberClick = false;
        if(ui->total_txtline->text().isEmpty()){
            ui->total_txtline->setText("0");
            ui->formular_txtline->setText("0"+op);
        }

        else if(ui->formular_txtline->text().isEmpty()){

            //QString previnput = ui->formular_txtline->text();
            QString input = ui->total_txtline->text();
            ui->formular_txtline->setText(input+op);

        }
        else{
            QString previnput = ui->formular_txtline->text();
            QString input = ui->total_txtline->text();
            ui->formular_txtline->setText(previnput+input+op);
        }
    }else {

        QString previnput = ui->formular_txtline->text();
        previnput.remove(previnput.size()-1, previnput.size());

        ui->formular_txtline->setText(previnput+op);

    }




       // QString input = ui->total_txtline->text();
       // QString inputformular = ui->formular_txtline->text();
       // ui->formular_txtline->setText(input+op);

}


//Print numpad numbers to textline
void MainWindow::on_zero_btn_clicked()
{
    //QString zero = "0";
    if(ui->total_txtline->text()==("0")){

    }
    else{
    appenedin("0");
    }

}

void MainWindow::on_one_btn_clicked()
{
    appenedin("1");
}

void MainWindow::on_two_btn_clicked()
{
    appenedin("2");
}

void MainWindow::on_three_btn_clicked()
{
    appenedin("3");
}

void MainWindow::on_four_btn_clicked()
{
    appenedin("4");
}

void MainWindow::on_five_btn_clicked()
{
    appenedin("5");
}

void MainWindow::on_six_btn_clicked()
{
    appenedin("6");
}

void MainWindow::on_seven_btn_clicked()
{
    appenedin("7");
}

void MainWindow::on_eight_btn_clicked()
{
    appenedin("8");
}

void MainWindow::on_nine_btn_clicked()
{
    appenedin("9");
}

void MainWindow::on_dot_btn_clicked()
{
    if(ui->total_txtline->text().isEmpty()){

    }
    else if(ui->total_txtline->text().contains(".")){

    }
    else{
    appenedin(".");
    }
}

void MainWindow::on_plus_btn_clicked()
{

    oparatorclick = true;
    notempty_appenedin("+");
    //appenedin("+");
}

void MainWindow::on_min_btn_clicked()
{
    oparatorclick = true;
    notempty_appenedin("-");
}

void MainWindow::on_multiply_btn_clicked()
{
    oparatorclick = true;
    notempty_appenedin("*");
}

void MainWindow::on_divide_btn_clicked()
{
    oparatorclick = true;
    notempty_appenedin("/");
}
//-END-Print numpad numbers to textline

void MainWindow::on_c_btn_clicked()
{
    ui->formular_txtline->setText("");
    ui->total_txtline->setText("");
}

void MainWindow::on_ce_btn_clicked()
{
    ui->total_txtline->setText("");
}

void MainWindow::on_plusormin_btn_clicked()
{
    QString input = ui->total_txtline->text();
    if(ui->total_txtline->text().contains("-")){
        input.remove(0,1);
        ui->total_txtline->setText(input);
    }
    else{
        ui->total_txtline->setText("-"+input);
    }
}

void MainWindow::on_del_btn_clicked()
{
    QString input = ui->total_txtline->text();
    input = input.remove( (input.size()-1) , (input.size()) );
    ui->total_txtline->setText(input);
}

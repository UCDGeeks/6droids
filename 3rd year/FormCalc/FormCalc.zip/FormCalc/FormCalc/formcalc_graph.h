#ifndef FORMCALC_GRAPH_H
#define FORMCALC_GRAPH_H

#include <QWidget>
#include "dependencies.h"
#include "qcustomplot.h"

namespace Ui {
class FormCalc_Graph;
}

class FormCalc_Graph : public QWidget
{
    Q_OBJECT

public:
    explicit FormCalc_Graph(QWidget *parent = 0);
    ~FormCalc_Graph();
    //Graph
    void setupPlot();
    double getPowerOfX(double value, double xValMax);

private slots:
    //Graph
    void horzScrollBarChanged(int value);
    void vertScrollBarChanged(int value);
    void xAxisChanged(QCPRange range);
    void yAxisChanged(QCPRange range);

    void on_btn_DrawGraph_clicked();

    void on_fxgraph1_clicked(bool checked);

    void on_gxgraph1_clicked(bool checked);

    void on_fx2_graph_clicked(bool checked);

    void on_gx2_graph_clicked(bool checked);

    void on_btn_DrawGraph_2_clicked();

private:
    Ui::FormCalc_Graph *ui;
};

#endif // FORMCALC_GRAPH_H

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GA;

import src.CandidateSolution;
import src.PreferenceTable;



/**
 *
 * @author Sahitha Nelanga
 */
public class Population {

    // Holds population of tours
    CandidateSolution[] tours;

    // Construct a population
    public Population(int populationSize, PreferenceTable preferenceTable) {
        tours = new CandidateSolution[populationSize];
        // If we need to initialise a population of tours do so
        if (preferenceTable != null) {
            // Loop and create individuals
            for (int i = 0; i < populationSize(); i++) {
                CandidateSolution newTour = new CandidateSolution(preferenceTable);
                //newTour.generateIndividual();
                saveTour(i, newTour);
            }
        }
    }
    
    // Saves a tour
    public void saveTour(int index, CandidateSolution tour) {
        tours[index] = tour;
    }
    
    // Gets a tour from population
    public CandidateSolution getTour(int index) {
        return tours[index];
    }

    // Gets the best tour in the population
    public CandidateSolution getFittest() {
        CandidateSolution fittest = tours[0];
        // Loop through individuals to find fittest
        for (int i = 1; i < populationSize(); i++) {
            if (fittest.getFitness() <= getTour(i).getFitness()) {
                fittest = getTour(i);
            }
        }
        return fittest;
    }

    // Gets population size
    public int populationSize() {
        return tours.length;
    }
}

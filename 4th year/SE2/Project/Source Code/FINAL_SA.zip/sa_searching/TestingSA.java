/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package sa_searching;

import src.PreferenceTable;

/**
 *
 * @author Tharkana
 */
public class TestingSA {
    public static void main(String[] args) {
        
        PreferenceTable p = new PreferenceTable(System.getProperty("user."
                + "dir") + "/src/data/Project allocation data.tsv");
        SimulatedAnnealing.performSearch(p);
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package src;

import ga_searching.Individual;
import java.util.Random;
import sa_searching.SimulatedAnnealing;
import view.Home;

/**
 *
 * @author priyanga
 */
public class ApasMain {

    final static int ELITISM_K = 5;
    final static int POP_SIZE = 200 + ELITISM_K;  // population size
    final static int MAX_ITER = 2000;             // max number of iterations
    final static double MUTATION_RATE = 0.05;     // probability of mutation
    final static double CROSSOVER_RATE = 0.7;     // probability of crossover

    private static Random m_rand = new Random();  // random-number generator
    private Individual[] m_population;
    private double totalFitness;

    public static void main(String[] args) {
        PreferenceTable p = new PreferenceTable(System.getProperty("user."
                + "dir") + "/src/data/Project allocation data.tsv");
//		p.printVectorContents();
//		
//		System.out.println(p.getEntryFor("Alan Turing"));
//		for(StudentEntry element:p.getAllStudentEntries()) {
//			System.out.println(element);
//		}
//		System.out.println(p.getRandomStudent());

//		System.out.println(p.getAllStudentEntries());
        p.fillPreferencesOfAll(10);
//		System.out.println(p.getAllStudentEntries());
//		CandidateSolution sol = new CandidateSolution(p);
//		String name = p.getRandomStudent().getStudentName();
//		System.out.println("Assignment: "+sol.getAssignmentFor(name));
//		System.out.println("Randon Assignment: "+sol.getRandomAssignment());

//		System.out.println("Solution One");
//		CandidateSolution sol1 = new CandidateSolution(p);
//		System.out.println("Energy: " + sol1.getEnergy());
//		System.out.println("Fitness: " + sol1.getFitness());
//		
//		System.out.println("Solution Two");
//		CandidateSolution sol2 = new CandidateSolution(p);
//		System.out.println("Energy: " + sol2.getEnergy());
//		System.out.println("Fitness: " + sol2.getFitness());
//                SimulatedAnnealing sa = new SimulatedAnnealing();
        Home home = new Home();
        home.setVisible(true);
        SimulatedAnnealing.performSearch(p);

    }

}

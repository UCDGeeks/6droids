/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ga_searching;

import java.util.Hashtable;
import src.CandidateSolution;
import src.PreferenceTable;

/**
 *
 * @author Tharkana
 */
public class TestingGA {
    
    public static void main(String[] args) {
        PreferenceTable p = new PreferenceTable(System.getProperty("user."
                + "dir") + "/src/data/Project allocation data.tsv");
        
        // Print final results
        CandidateSolution fitest = GA.searchForBestSolution( p, 100);
//        System.out.println("Finished");
        System.out.println("Final Energy: " + fitest.getEnergy());
//        System.out.println("Solution:");
//        System.out.println(fitest);
//        
//        System.out.println("\n\n\n No. of Students who got a project which they didn't ask for: " + fitest.gettInvalidMappingCount());
//        System.out.println("Average DIssapointment: " + fitest.getAverageDissapoinment());
//        System.out.println("Total DIssapointment: " + fitest.getTotalDissapoinment());
        
    }
    
}

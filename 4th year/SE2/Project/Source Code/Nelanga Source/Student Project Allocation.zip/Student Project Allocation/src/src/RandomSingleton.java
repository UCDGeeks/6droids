/*
 * @author      : Tharkana Kodagoda
 * @version     : Programming Assignment #2
 * @description : To get a Single Random Instance through out this Application
 */
package src;

import java.util.Random;


public class RandomSingleton extends Random{

    private static RandomSingleton RND = null;

    private RandomSingleton() {
        // TO stop using constructores to create instance of Random.
    }

    public static RandomSingleton getInstance() {
        if (RND == null) {
            RND = new RandomSingleton();
        }
        return RND;
    }

}

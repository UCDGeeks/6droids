/*
 * GA.java
 * Manages algorithms for evolving population
 */

package ga_searching;

import java.util.Vector;
import src.CandidateAssignment;
import src.CandidateSolution;
import src.PreferenceTable;
import src.RandomSingleton;

public class GA {

    /* GA parameters */
    private static final double mutationRate = 0.6;
    private static final int solutionPopulationSize = 5;
    private static final boolean elitism = true;

    public static CandidateSolution searchForBestSolution(PreferenceTable preferenceTable, int generations) {
        Population pop = new Population(preferenceTable.getAllStudentEntries().size(), preferenceTable);
        System.out.println("Initial Energy: " + pop.getFittest().getEnergy());
        for (int i = 0; i < generations; i++) {
            pop = evolvePopulation(pop);
        }

        CandidateSolution sol = pop.getFittest();
        return sol;
    }

    // Evolves a population over one generation
    public static Population evolvePopulation(Population population) {
        Population newPopulation = new Population(population.populationSize(), null);

        CandidateSolution fittestCandidateSolution = population.getFittest();
        newPopulation.saveCandidateSolution(0, fittestCandidateSolution);

        // Crossover population
        // Loop over the new population's size and create individuals from
        // Current population
        for (int i = 1; i < newPopulation.populationSize(); i++) {
            CandidateSolution candidateSolutionParent1 = crossoverSelection(population);
            CandidateSolution candidateSolutionParent2 = crossoverSelection(population);
            CandidateSolution candidateSolutionChild = crossover(candidateSolutionParent1, candidateSolutionParent2);
            mutate(candidateSolutionChild);
            newPopulation.saveCandidateSolution(i, candidateSolutionChild);            
        }
        return newPopulation;
    }

    // Applies crossover to a set of parents and creates offspring
    public static CandidateSolution crossover(CandidateSolution parent1, CandidateSolution parent2) {
        // Create new child CandidateSolution
        CandidateSolution child = new CandidateSolution();

        // Get start and end sub CandidateSolution positions for parent1's CandidateSolution
        int startPos = RandomSingleton.getInstance().nextInt(parent1.getTableSize());
        int endPos = RandomSingleton.getInstance().nextInt(parent1.getTableSize());

        // Loop and add the sub CandidateSolution from parent1 to our child
        for (int i = 0; i < parent1.getTableSize(); i++) {
            String studentName = parent1.getStudentNames().get(i);
            CandidateAssignment candidateAssignment;
            // If our start position is less than the end position
            if (startPos < endPos && i > startPos && i < endPos) {
                candidateAssignment = parent1.getAssignmentFor(studentName);
                child.addAssignment(studentName, candidateAssignment);
            } // If our start position is larger
            else if (startPos > endPos) {
                candidateAssignment = parent2.getAssignmentFor(studentName);
                child.addAssignment(studentName, candidateAssignment);
            }
        }

        // Loop through parent2's 
        for (int i = 0; i < parent2.getTableSize(); i++) {
            // If child doesn't have the solution add it
            if (child.getAssignmentFor(parent2.getStudentNames().get(i)) == null) {
                child.addAssignment(parent2.getStudentNames().get(i), parent2.getAssignmentFor(parent2.getStudentNames().get(i)));
            }
        }

        return child;
    }

    // Mutate a CandidateAssignment using swap mutation
    private static void mutate(CandidateSolution candidateSolution) {
        // Loop through CandidateAssignment
        Vector<String> studentNames = candidateSolution.getStudentNames();
        for (int pos1 = 0; pos1 < candidateSolution.getTableSize(); pos1++) {
            
            // Apply mutation rate            
            if (RandomSingleton.getInstance().nextFloat() < mutationRate) {
                int pos2 = RandomSingleton.getInstance().nextInt(candidateSolution.getTableSize());
                CandidateAssignment city1 = candidateSolution.getAssignmentFor(studentNames.elementAt(pos1));
                CandidateAssignment city2 = candidateSolution.getAssignmentFor(studentNames.elementAt(pos2));
                String assigmnet1Pref = city1.getPreference();
                
                if( !city1.getStudent().hasPreassignedProject() && !city2.getStudent().hasPreassignedProject() && city1.getStudent().hasPreference(city2.getPreference()) && city2.getStudent().hasPreference(city1.getPreference()) ){
                    do{
                        city1.randomizeAssignment();
                    }while( !city1.getPreference().equals(city2.getPreference()) );

                    do{
                        city2.randomizeAssignment();
                     
                    }while( !city2.getPreference().equals(assigmnet1Pref) );
                }
                
            }
        }
    }



    // Selects candidate solution for crossover
    private static CandidateSolution crossoverSelection(Population pop) {
        // Create a candidate solution population
        Population solution = new Population(solutionPopulationSize, null);
        // For each place in the candidate solution population get a random candidate solution and
        // add it
        for (int i = 0; i < solutionPopulationSize; i++) {
            int randomId = RandomSingleton.getInstance().nextInt(pop.populationSize());
            solution.saveCandidateSolution(i, pop.getCandidateSolution(randomId));
        }
        // Return the fittest solution
        return solution.getFittest();
    }
}

package ga_searching;

import src.CandidateSolution;
import src.PreferenceTable;



public class Population {

    // Holds population of CandidateSolution
    CandidateSolution[] candidateSolutions;

    // Construct a population
    public Population(int populationSize, PreferenceTable preferenceTable) {
        candidateSolutions = new CandidateSolution[populationSize];
        // If we need to initialise a population of CandidateSolution do so
        if (preferenceTable != null) {
            // Loop and create individuals
            for (int i = 0; i < populationSize(); i++) {
                CandidateSolution newCandidateSolution = new CandidateSolution(preferenceTable);                
                saveCandidateSolution(i, newCandidateSolution);
            }
        }
    }
    
    // Saves a CandidateSolution
    public void saveCandidateSolution(int index, CandidateSolution CandidateSolution) {
        candidateSolutions[index] = CandidateSolution;
    }
    
    // Gets a CandidateSolution from population
    public CandidateSolution getCandidateSolution(int index) {
        return candidateSolutions[index];
    }

    // Gets the best CandidateSolution in the population
    public CandidateSolution getFittest() {
        CandidateSolution fittest = candidateSolutions[0];
        // Loop through individuals to find fittest
        for (int i = 1; i < populationSize(); i++) {
            if (fittest.getFitness() <= getCandidateSolution(i).getFitness()) {
                fittest = getCandidateSolution(i);
            }
        }
        return fittest;
    }

    // Gets population size
    public int populationSize() {
        return candidateSolutions.length;
    }
}

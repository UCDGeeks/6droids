/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sa_searching;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import src.CandidateAssignment;
import src.CandidateSolution;

/**
 *
 * @author priyanga
 */
public class SimulatedAnnealing {

    static Hashtable<Integer, CandidateSolution> dataSet = new Hashtable();

    // Calculate the acceptance probability
    public static double acceptanceProbability(int newEnergy, int energy, double temperature) {
        // If the new solution is better, accept it
        if (newEnergy < energy) {
            return 1.0;
        }
        // If the new solution is worse, calculate an acceptance probability
        return Math.exp((newEnergy - energy) / temperature);
    }

    public static Hashtable shuffleTable(Hashtable table) {
        Hashtable<String, src.CandidateAssignment> oldTable = table;
        Hashtable<String, src.CandidateAssignment> newTable = new Hashtable();
        List keys = new ArrayList();

        for (Map.Entry<String, CandidateAssignment> entry : oldTable.entrySet()) {
            String key = entry.getKey().toString();
            if (key != null) {
                keys.add(key);
            }
        }

        // shuffle the list
        Collections.shuffle(keys);

        for (int i = 0; i < keys.size(); i++) {
            String value = keys.get(i).toString();
            newTable.put(value, oldTable.get(value));
            if (i == (keys.size() - 1)) {
                // Last item
                newTable.put(value, oldTable.get(value));
            }
        }

        return newTable;
    }

    public static void searching(src.PreferenceTable p) {
        // Set initial tempature
        double temp = 1.0;
        // Set minimum tempature
        double tempMin = 0.00001;
        // Cooling rate
        double coolingRate = 0.9;

        // Initialize intial solution
        src.CandidateSolution currentSolution = new src.CandidateSolution(p);
        // Randomly reorder the CandidateSolutions
        currentSolution = new src.CandidateSolution(shuffleTable(currentSolution.getTable()));

        System.out.println("Initial solution energy: " + currentSolution.getEnergy());

        // Set as current best
        src.CandidateSolution best = new src.CandidateSolution(currentSolution.getTable());

        // Loop until system has cooled
        while (temp > tempMin) {
            // Create new neighbour CandidateSolution
            src.CandidateSolution newSolution = new src.CandidateSolution(currentSolution.getTable());

            // Get a random positions in the CandidateSolution
            String studentName1 = p.getRandomStudent().getStudentName();
            String studentName2 = p.getRandomStudent().getStudentName();

            // Get the assignment at selected positions in the CandidateSolution
            src.CandidateAssignment assignSwap1 = newSolution.getAssignmentFor(studentName1);
            src.CandidateAssignment assignSwap2 = newSolution.getAssignmentFor(studentName2);

            // Swap them
            newSolution.setAssignment(studentName1, assignSwap2);
            newSolution.setAssignment(studentName2, assignSwap1);

            // Get energy of solutions
            int currentEnergy = currentSolution.getEnergy();
            int neighbourEnergy = newSolution.getEnergy();

            // Decide if we should accept the neighbour
            if (acceptanceProbability(neighbourEnergy, currentEnergy, temp) > Math.random()) {
                currentSolution = new src.CandidateSolution(newSolution.getTable());
            }

            // Keep track of the best solution found
            if (currentSolution.getEnergy() < best.getEnergy()) {
                best = new src.CandidateSolution(currentSolution.getTable());
            }

            // Cool system
            temp *= coolingRate;
        }

        dataSet.put(best.getEnergy(), best);
        System.out.println("Best solution energy: " + best.getEnergy());
        System.out.println("DataSet: " + best.getTable());
    }

    public static CandidateSolution performSearch(src.PreferenceTable p) {
        int energyBest = 0;
        boolean isFirstTime = true;

        for (int i = 0; i < 10; i++) {
            System.out.println("SA Searching Term : " + (i + 1));
            searching(p);
            System.out.println("\n");
        }

        for (Map.Entry<Integer, CandidateSolution> entry : dataSet.entrySet()) {
            int key = entry.getKey();

            if (isFirstTime) {
                energyBest = key;
            } else if (energyBest > key) {
                energyBest = key;
            }

            isFirstTime = false;
        }

//        System.out.println("=============================================== \n"
//                + "Final Best Solution Energy: " + energyBest);
//        System.out.println("\nStudent Name: \t\t Assigned Project:");
//           int count = 0;
//        for (Iterator it = dataSet.get(energyBest).entrySet().iterator(); it.hasNext();) {
//            Map.Entry<String, CandidateAssignment> entry = (Map.Entry<String, CandidateAssignment>) it.next();
//            String key = entry.getKey();
//            CandidateAssignment value = entry.getValue();
////            value.getStudent().hasPreference(key)
//            if( !value.getStudent().hasPreference(value.getPreference())){
//                count++;
//            }
//            
//            System.out.println(key + "\t\t" + value.getPreference());
//        }
//        System.out.println("\n\n\n No. of Students who got a project which they didn't ask for: " + count);
        
        return dataSet.get(energyBest);
    }
}

package assignment3;

import com.sun.corba.se.impl.orbutil.closure.Constant;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Map.Entry;
import java.util.Vector;

public class CandidateSolution {

    public static final int energyPenalty = 1000;
    private Hashtable<String, CandidateAssignment> table;

    public CandidateSolution(PreferenceTable p) {
        this.table = new Hashtable<String, CandidateAssignment>();
        for (StudentEntry student : p.getAllStudentEntries()) {
            table.put(student.getStudentName(), new CandidateAssignment(student));
        }
    }

    public CandidateAssignment getAssignmentFor(String sname) {
        return table.get(sname);
    }

    public CandidateAssignment getRandomAssignment() {
        Vector<String> keySet = new Vector<String>(table.keySet());
        return table.get(keySet.elementAt(Main.RND.nextInt(keySet.size())));
    }

    public int getEnergy() {
        int assignmentsSum = 0;
        int energySum = 0;
        int sameStudentCounter = 0;
        Enumeration names;
        String str;
        Hashtable projects = new Hashtable();

        for (Entry<String, CandidateAssignment> entry : table.entrySet()) {
            String key = entry.getKey();
            CandidateAssignment value = entry.getValue();
            assignmentsSum += value.getEnergy();
            names = projects.keys();

            // Runs only ones to add first project String into the hashtable
            if (projects.isEmpty()) {
                projects.put(key, value);
            } else {
                while (names.hasMoreElements()) {
                    str = names.nextElement().toString();
                    if (value == projects.get(str)) {
                        sameStudentCounter++;
                    } else {
                        projects.put(key, value);
                    }
                }
            }
        }

        if (sameStudentCounter > 2) {
            energySum = energyPenalty;
        }

        return assignmentsSum + energySum;
    }

    public int getFitness() {
        return -(getEnergy());
    }
}

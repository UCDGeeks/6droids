package assignment3;

import java.util.Random;

public class Main {

    protected static Random RND = new Random();

    public static void main(String[] args) {
        PreferenceTable p = new PreferenceTable(System.getProperty("user."
                + "dir") + "/src/data/Project allocation data.tsv");

//		p.printVectorContents();
//		
//		System.out.println(p.getEntryFor("Alan Turing"));
//		for(StudentEntry element:p.getAllStudentEntries()) {
//			System.out.println(element);
//		}
//		System.out.println(p.getRandomStudent());

        System.out.println(p.getAllStudentEntries());
        p.fillPreferencesOfAll(10);
        System.out.println(p.getAllStudentEntries());
        CandidateSolution sol = new CandidateSolution(p);
        String name = p.getRandomStudent().getStudentName();
                
        System.out.println("Assignment: " + sol.getAssignmentFor(name));
        System.out.println("Randon Assignment: " + sol.getRandomAssignment());
        
        CandidateAssignment cand = sol.getAssignmentFor(name);
        System.out.println("cand :" + cand);

        System.out.println("Energy: " + sol.getEnergy());
        System.out.println("Fitness: " + sol.getFitness());
    }

}

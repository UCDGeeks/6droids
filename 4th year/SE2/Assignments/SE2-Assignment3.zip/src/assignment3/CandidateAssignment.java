package assignment3;

public class CandidateAssignment {

    private StudentEntry student;
    private String previousPreference, currentPreference;

    public CandidateAssignment(StudentEntry s) {
        student = s;
        randomizeAssignment();
    }

    public void randomizeAssignment() {
        previousPreference = currentPreference;
        currentPreference = student.getRandomPreference().intern();
    }

    public void undoChange() {
        currentPreference = previousPreference;
    }
    
    public int getEnergy() {
        int ans = student.getRanking(currentPreference.intern()) + 1;
        return ans * ans;
    }

    public String toString() {
        return student.getStudentName() + ": " + currentPreference;
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment2;

import java.util.Vector;

import assignment2.RNDSingleton;
import java.util.Iterator;
import java.util.Random;

public class StudentEntry {

    private String name;
    private boolean hasProjectPreassigned;
    private Vector<String> orderedPreferences;
    private int numberOfStatedPreferences;
    private String projectAssigned = null;
    Random RND = RNDSingleton.getInstance();

    public StudentEntry(String n) {
        name = n;
    }

    /**
     *
     * @return a String containing the name of this particular student
     */
    public String getStudentName() {
        return name;
    }

    public void setHasProjectPreassigned(boolean bool) {
        hasProjectPreassigned = bool;
    }

    public void setOrderedPreferences(Vector<String> v) {
        orderedPreferences = v;
        numberOfStatedPreferences = orderedPreferences.size();
    }

    public Vector<String> getOrderedPreferences() {
        return orderedPreferences;
    }

    public void preassignProject(String pname) {
        if (orderedPreferences.size() == 1 && hasProjectPreassigned) {
            projectAssigned = pname;
        }
    }

    public boolean hasPreassignedProject() {
        if (hasProjectPreassigned && projectAssigned != null) {
            return true;
        }
        return false;
    }

    public int getNumberOfStatedPreferences() {
        return numberOfStatedPreferences;
    }

    public void addProject(String pname) {
        orderedPreferences.addElement(pname.intern());
    }

    public String toString() {
        return "Name: " + name + " prefereces:" + getOrderedPreferences();
    }
    
    public boolean hasPreference(String	preference) {
        Vector<String> v;
        v = getOrderedPreferences();
        Iterator i = v.iterator();
        while (i.hasNext()) {
            if(i.next().toString().equals(preference))
                return true;
//            System.out.println(i.next());
        }
        return false;
    }
    
    public String getRandomPreference() {
        String randomeStudent = name;
        Vector<String> preferences;
        preferences = getOrderedPreferences();
        String randomPreference = preferences.get(RND.nextInt(preferences.size()));
        return randomPreference;
    }
}

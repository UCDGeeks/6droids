/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment2;

public class Assignment2 {

    /**
     * @param args the command line arguments
     *
     */
    public static void main(String[] args) {
        PreferenceTable pTable = new PreferenceTable(System.getProperty("user."
                + "dir") + "/src/assignment2/data/Project allocation data.tsv");
        StudentEntry sEntry;
        sEntry = new StudentEntry(pTable.getRandomStudent().getStudentName());
        
        CandidateAssignment assg = 
                new CandidateAssignment(pTable.getRandomStudent());
        CandidateSolution sol = new CandidateSolution(pTable);
        CandidateAssignment cand = 
                sol.getAssignmentFor(pTable.getRandomStudent().getStudentName());		
	CandidateAssignment rand = sol.getRandomAssignment(); // SA/GA
        
//	System.out.println(pTable.getEntryFor("Alan Turing"));
//        System.out.println(pTable.getAllStudentEntries());
//        System.out.println(pTable.getRandomStudent());
//        System.out.println(pTable.getRandomPreference());
        
//        System.out.println(sEntry.getRandomPreference());

//        System.out.println(assg.getStudentEntry());
//        System.out.println(assg.getAssignedProject());
//        System.out.println(assg.getCandidate());
        
        System.out.println(sol.getAssignmentFor(pTable.getRandomStudent().getStudentName()));
//        System.out.println(sol.getRandomAssignment());
        
//        pTable.printVectorContents();

    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment2;

import java.io.*;
import java.util.Hashtable;
import java.util.StringTokenizer;
import java.util.Vector;
import java.util.ArrayList;
import java.util.Random;

import assignment2.StudentEntry;
import assignment2.RNDSingleton;

public class PreferenceTable {

    private Vector<Vector<String>> table;
    private Hashtable<String, StudentEntry> studentLookup = new Hashtable<String, StudentEntry>();
    Random RND = RNDSingleton.getInstance();
    
    /**
     * Empty constructor
     */
    public PreferenceTable() {

    }

    /**
     * Constructor that takes a file name, opens said file and loads the
     * contents
     *
     * @param filename the path to the file
     */
    public PreferenceTable(String filename) {
        table = loadContentFromFile(filename);
    }

    /**
     * Opens a file, reads in each line which it splits into tokens and then
     * stores each token as a String in a Vector. Each line is represented as a
     * Vector of Strings and the table is represented as a Vector of Vectors of
     * Strings.
     *
     * @param filename the path to the file
     * @return the vector representing the file content
     */
    private Vector<Vector<String>> loadContentFromFile(String filename) {
        Vector<Vector<String>> t = new Vector<Vector<String>>();
        FileInputStream stream = null;
        BufferedReader input;
        String line;
        StringTokenizer tokens;

        try {
            stream = new FileInputStream(filename);
        } catch (FileNotFoundException e) {
            System.out.println("File is not found!");
            e.printStackTrace();
        }

        input = new BufferedReader(new InputStreamReader(stream));

        try {
            while ((line = input.readLine()) != null) {
                tokens = new StringTokenizer(line, "\t");
                Vector<String> v = new Vector<String>();
                while (tokens.hasMoreTokens()) {
                    String next = tokens.nextToken();
                    v.add(next);
                }
                t.add(v);
                if (t.size() > 1) {
                    StudentEntry student = new StudentEntry(v.get(0));
                    if (v.get(1).equalsIgnoreCase("yes")) {
                        student.setHasProjectPreassigned(true);
                    } else {
                        student.setHasProjectPreassigned(false);
                    }
                    Vector<String> preferredProjects = new Vector<String>();
                    for (int i = 2; i < v.size(); i++) {
                        preferredProjects.add(v.get(i));
                    }
                    student.setOrderedPreferences(preferredProjects);
                    studentLookup.put(v.get(0), student);
                }
            }
            input.close();
        } catch (IOException e) {
            System.out.println("Error reading file!");
            e.printStackTrace();
        }

        return t;
    }

    public Vector<StudentEntry> getAllStudentEntries() {
        Vector<StudentEntry> studentEntries = new Vector<StudentEntry>();
        for (String key : studentLookup.keySet()) {
            studentEntries.addElement(studentLookup.get(key));
        }
        return studentEntries;
    }

    public StudentEntry getEntryFor(String sname) {
        try {
            return studentLookup.get(sname);
        } catch (NullPointerException e) {
            return null;
        }

    }
    
    public StudentEntry getRandomStudent() {
        ArrayList<String> keys;
        keys = new ArrayList<>(studentLookup.keySet());
        String randomKey = keys.get(RND.nextInt(keys.size()));
        StudentEntry randomeStudent = studentLookup.get(randomKey);
        return randomeStudent;
    }    

    public String getRandomPreference() {
        String randomeStudent = getRandomStudent().getStudentName();
        Vector<String> Prefereces = getEntryFor(randomeStudent)
                .getOrderedPreferences();
        String randomPreferece = Prefereces.get(RND.nextInt(Prefereces.size()));
        return "Random Student Name: " + randomeStudent + 
               "\nRandom Preferece: " + randomPreferece;
    }

    public void fillPreferencesOfAll(int maxPrefs) {
        StudentEntry sEntry;
        sEntry = new StudentEntry(getRandomStudent().getStudentName());
        if(sEntry.getNumberOfStatedPreferences() < maxPrefs) {
            sEntry.addProject(sEntry.getRandomPreference().intern());
        }
    }
    
    /**
     * Prints the Vector out to the console, used for testing
     */
    public void printVectorContents() {
        System.out.println(table);
    }
}

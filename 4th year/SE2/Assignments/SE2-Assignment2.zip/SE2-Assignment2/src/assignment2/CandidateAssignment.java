/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment2;

import assignment2.StudentEntry;
import java.util.Hashtable;
/**
 *
 * @author priyanga
 */
public class CandidateAssignment {
    
    private String candidate;
    private String preProject;
    private String project = null;
    private StudentEntry sEntry = new StudentEntry("Donald Trump");
    
    /**
     * Encapsulate constructor
     * @param name
     */
    CandidateAssignment(StudentEntry entry) {
        this.sEntry = entry;
        setCandidate(entry);
        randomizeAssignment(entry);
    }
    
    public void randomizeAssignment(StudentEntry entry) {
        this.preProject = project;
        setAssignedProject(entry.getRandomPreference());
    }
    
    public void undoChange() {
        project = preProject;
    }
    
    private void setCandidate(StudentEntry entry) {
        this.candidate = entry.getStudentName();
    }
    
    private void setAssignedProject(String projectName) {
        this.project = projectName;
    }
    
    public StudentEntry	getStudentEntry() {
        return this.sEntry;
    }
    
    public String getAssignedProject() {
        return this.project;
    }
    
    public String getCandidate() {
        return this.candidate;
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment2;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Random;
import java.util.Vector;

/**
 *
 * @author priyanga
 */
public class CandidateSolution {
    
    Hashtable cAssignments = new Hashtable();
    private Hashtable<String, CandidateAssignment> candidateLookup = 
            new Hashtable<String, CandidateAssignment>();
    Random RND = RNDSingleton.getInstance();
    
    public CandidateSolution(PreferenceTable pTable) {
        Vector<StudentEntry> entries = pTable.getAllStudentEntries();
        Iterator i = entries.iterator();
        
        while (i.hasNext()) {
//            System.out.println(i.next());
            CandidateAssignment cand;
            cand = new CandidateAssignment((StudentEntry) i.next());
            String key = cand.getCandidate();
//                        System.out.println(key);
            candidateLookup.put(key, cand);
        }
            
        
    }
    
    public CandidateAssignment getAssignmentFor(String cName) {
        Enumeration names;
        String str = null;
        names = candidateLookup.keys();
        System.out.println("Candidate Name: " + cName);
        while(names.hasMoreElements()) {
           str = (String) names.nextElement();
           if(cName == null ? str == null : cName.equals(str)) {
               System.out.println(str + ": " + candidateLookup.get(cName));
           }
        }
        return candidateLookup.get(cName);
    }
    
    public CandidateAssignment getRandomAssignment() {
        ArrayList<String> keys;
        keys = new ArrayList<>(candidateLookup.keySet());
        String randomKey = keys.get(RND.nextInt(keys.size()));
        CandidateAssignment randomeAssignment = candidateLookup.get(randomKey);
        return randomeAssignment;
    }
}
